"""Check known stock overlays after fusion, without treating silence as proof."""
import io
import re
from difflib import SequenceMatcher
from concurrent.futures import ThreadPoolExecutor, wait
import numpy as np
from PIL import Image, ImageOps
from . import ocr_guard

def is_stock_credit_line(word, score):
    """Recognize an overlaid stock credit, allowing a few OCR mistakes."""
    # OCR may split "Credit:" and the photographer name into separate boxes.
    if score < .7 or len(word) < 6 or not re.search(r'[:：/]', word):
        return False
    head = re.split(r'[:：/]', word, maxsplit=1)[0]
    letters = ''.join(c for c in head.lower() if c.isalpha())
    return 5 <= len(letters) <= 8 and SequenceMatcher(None, letters, 'credit').ratio() >= .66

def check_known_overlays(body, *, check_cancelled=None):
    image=ImageOps.exif_transpose(Image.open(io.BytesIO(body))).convert('RGB')
    w,h=image.size
    # Overview covers unexpected locations; native crops preserve small credit
    # and corner-number lettering that disappears when the whole photo shrinks.
    crops=[(0,0,w,h,False),(int(w*.35),int(h*.50),w,int(h*.84),False),(0,int(h*.88),int(w*.42),h,False)]
    # The overview can erase small readable branding elsewhere in the photo.
    # Overlapping native tiles cover the entire frame, including seam edges;
    # they are evidence checks only and never rescale the exported image.
    crops.extend((left,top,min(w,left+640),min(h,top+480),True)
        for top in range(0,h,384) for left in range(0,w,512))
    # Keep all evidence crops and their order. Only two may be in flight, so a
    # positive result or cancellation leaves at most one inference to finish.
    with ThreadPoolExecutor(max_workers=2) as pool:
        for start in range(0,len(crops),2):
            pending=[]
            for left,top,right,bottom,native in crops[start:start+2]:
                if check_cancelled:check_cancelled()
                crop=image.crop((left,top,right,bottom))
                scale=1 if native else min(1,900/max(crop.size))
                if scale<1:crop=crop.resize((max(1,round(crop.width*scale)),max(1,round(crop.height*scale))),Image.Resampling.LANCZOS)
                options={'check_cancelled':check_cancelled} if check_cancelled else {}
                pending.append((left,top,scale,pool.submit(ocr_guard.text_lines,np.asarray(crop),**options)))
            for left,top,scale,future in pending:
                while True:
                    if check_cancelled:check_cancelled()
                    if wait((future,),timeout=.1).done:break
                lines=future.result()
                if check_cancelled:check_cancelled()
                if lines is None:return {'status':'unavailable','reason_code':'output_check_unavailable'}
                for x,y,end,bottom_y,word,score in lines:
                    letters=''.join(c for c in word.lower() if c.isalnum())
                    brand=score>=.5 and ('getty' in letters or 'istock' in letters)
                    credit=is_stock_credit_line(word,score)
                    corner=(score>=.7 and letters.isdigit() and len(letters)>=6
                        and x/scale+left<=w*.04 and y/scale+top>=h*.93
                        and end/scale+left<=w*.30)
                    if brand or corner or credit:
                        return {'status':'suspected','reason_code':'remaining_watermark',
                            'evidence':'brand_text' if brand else 'credit_text' if credit else 'corner_number'}
    return {'status':'no_known_overlay_detected','reason_code':'no_known_overlay_detected'}

