# -*- coding: utf-8 -*-
"""
统一错误分类。

设计原则（对应交接要求第 6 条）：
    验证失败、无下载权限、链接失效、源文件不存在等错误必须分别说明，
    不允许全部折叠成一句"解析失败"，也不允许无限重试。

每个错误都有：
    code        —— 机器可读的错误码，前端按码分流
    title       —— 简短中文标题
    message     —— 面向用户的中文解释
    detail      —— 技术细节（可空）
    retryable   —— 是否值得重试（False 时前端直接放弃，绝不无限重试）
    http_status —— 关联的上游 HTTP 状态（可空）
"""

from __future__ import annotations


class GettyToolError(Exception):
    """本工具所有可预期错误的基类。"""

    code = "UNKNOWN"
    title = "未知错误"
    retryable = False

    def __init__(self, message: str = "", detail: str | None = None,
                 http_status: int | None = None, **extra):
        self.message = message or self.__class__.__doc__ or ""
        self.detail = detail
        self.http_status = http_status
        self.extra = extra
        super().__init__(self.message)

    def to_dict(self) -> dict:
        d = {
            "ok": False,
            "code": self.code,
            "title": self.title,
            "message": self.message,
            "retryable": self.retryable,
        }
        if self.detail:
            d["detail"] = self.detail
        if self.http_status is not None:
            d["http_status"] = self.http_status
        if self.extra:
            d["extra"] = self.extra
        return d


# --------------------------------------------------------------------------
# 1. 输入与地址校验类（本地就能判定，不发请求）
# --------------------------------------------------------------------------

class InvalidUrlError(GettyToolError):
    """URL 格式不合法，无法解析。"""
    code = "INVALID_URL"
    title = "链接格式不正确"
    retryable = False


class UnsupportedSchemeError(GettyToolError):
    """只允许 http / https，其他协议（file:、ftp:、data: 等）一律拒绝。"""
    code = "UNSUPPORTED_SCHEME"
    title = "不支持的协议"
    retryable = False


class UnsupportedHostError(GettyToolError):
    """目标主机不在允许列表内。"""
    code = "UNSUPPORTED_HOST"
    title = "不支持的网站"
    retryable = False


class BlockedPrivateTargetError(GettyToolError):
    """目标解析到内网 / 回环 / 保留地址，已按 SSRF 防护规则阻断。"""
    code = "BLOCKED_PRIVATE_TARGET"
    title = "已阻断内网地址访问"
    retryable = False


class BlockedRedirectError(GettyToolError):
    """重定向跳到了允许列表之外或内网地址，已阻断。"""
    code = "BLOCKED_REDIRECT"
    title = "重定向被阻断"
    retryable = False


class AssetIdMissingError(GettyToolError):
    """没能从链接里识别出 Getty 素材编号。"""
    code = "ASSET_ID_MISSING"
    title = "识别不出素材编号"
    retryable = False


# --------------------------------------------------------------------------
# 2. 网络类
# --------------------------------------------------------------------------

class DnsFailedError(GettyToolError):
    """域名解析失败。"""
    code = "DNS_FAILED"
    title = "域名解析失败"
    retryable = True


class NetworkError(GettyToolError):
    """连接中断、TLS 失败等底层网络问题。"""
    code = "NETWORK_ERROR"
    title = "网络连接失败"
    retryable = True


class TimeoutError_(GettyToolError):
    """请求超时。"""
    code = "TIMEOUT"
    title = "请求超时"
    retryable = True


class TooManyRedirectsError(GettyToolError):
    """重定向次数超过上限，停止跟随。"""
    code = "TOO_MANY_REDIRECTS"
    title = "重定向次数过多"
    retryable = False


class ResponseTooLargeError(GettyToolError):
    """响应体超过体积上限，中止下载。"""
    code = "RESPONSE_TOO_LARGE"
    title = "文件体积超过上限"
    retryable = False


# --------------------------------------------------------------------------
# 3. 上游 HTTP 状态类（各自独立，绝不合并）
# --------------------------------------------------------------------------

class BadSignatureError(GettyToolError):
    """上游返回 400：签名与请求参数不匹配。

    实测（素材 1292014419）确认的行为：
      · 只给 s=2048x2048、不带 k=/c=  -> HTTP 400
      · s=/k=/c= 三者齐备              -> HTTP 200，返回对应尺寸
      · 完全不带任何参数                -> HTTP 200，返回一个默认尺寸（612×407）
    也就是说 c= 签名与 s= 尺寸是绑定的，改尺寸必须换签名。
    """
    code = "HTTP_BAD_SIGNATURE"
    title = "签名参数无效（400）"
    retryable = False


class NoPermissionError(GettyToolError):
    """401 / 403：无权限或需要登录。"""
    code = "HTTP_NO_PERMISSION"
    title = "无下载权限（401/403）"
    retryable = False


class AssetNotFoundError(GettyToolError):
    """404：素材不存在或已被删除。"""
    code = "HTTP_ASSET_NOT_FOUND"
    title = "素材不存在（404）"
    retryable = False


class RateLimitedError(GettyToolError):
    """429：被限流。"""
    code = "HTTP_RATE_LIMITED"
    title = "请求过于频繁（429）"
    retryable = True


class UpstreamError(GettyToolError):
    """5xx：上游服务异常。"""
    code = "HTTP_UPSTREAM_ERROR"
    title = "上游服务异常（5xx）"
    retryable = True


class UnexpectedHttpError(GettyToolError):
    """其他未归类的 HTTP 状态。"""
    code = "HTTP_UNEXPECTED"
    title = "上游返回异常状态"
    retryable = False


# --------------------------------------------------------------------------
# 4. 响应内容类
# --------------------------------------------------------------------------

class ResponseIsHtmlError(GettyToolError):
    """拿到的是 HTML 而不是图片。

    典型场景：被 Cloudflare / 人机验证拦截，或素材页返回了登录页。
    这一类必须单独报，避免把验证码页面当成 JPG 存盘（交接要求第 3 条）。
    """
    code = "RESPONSE_IS_HTML"
    title = "上游返回的是网页，不是图片"
    retryable = False


class NotAnImageError(GettyToolError):
    """响应既不是已知图片格式，也不是可识别的 HTML。"""
    code = "NOT_AN_IMAGE"
    title = "响应内容不是图片"
    retryable = False


class ImageDecodeFailedError(GettyToolError):
    """文件头像图片，但解码失败——可能被截断或损坏。"""
    code = "IMAGE_DECODE_FAILED"
    title = "图片解码失败"
    retryable = False


# --------------------------------------------------------------------------
# 5. 图源与处理类
# --------------------------------------------------------------------------

class NoSourceFoundError(GettyToolError):
    """详情页里没有找到任何可用的公开图源。"""
    code = "NO_SOURCE_FOUND"
    title = "未找到可用图源"
    retryable = False


class SourceNotImplementedError(GettyToolError):
    """该图源需要凭据或尚未接入，不做任何假装成功的处理。"""
    code = "SOURCE_NOT_AVAILABLE"
    title = "该图源当前不可用"
    retryable = False


class ApiCredentialsMissingError(GettyToolError):
    """Getty 官方 API 需要 API Key 与访问令牌，当前未配置。"""
    code = "API_CREDENTIALS_MISSING"
    title = "未配置 Getty 官方 API 凭据"
    retryable = False


class ApiUnauthorizedError(GettyToolError):
    """官方 API 拒绝凭据或权限不足。"""
    code = "API_UNAUTHORIZED"
    title = "官方 API 鉴权失败"
    retryable = False


class NoDownloadSizeError(GettyToolError):
    """官方 API 返回的可用尺寸列表为空，账号无该素材下载权。"""
    code = "API_NO_DOWNLOAD_SIZE"
    title = "该账号对此素材无可用下载尺寸"
    retryable = False


class ProcessorUnavailableError(GettyToolError):
    """所选图像处理功能依赖缺失或参数不合法。"""
    code = "PROCESSOR_UNAVAILABLE"
    title = "图像处理功能不可用"
    retryable = False


# --------------------------------------------------------------------------
# 映射表：把上游 HTTP 状态翻成上面这些具体错误
# --------------------------------------------------------------------------

HTTP_STATUS_MAP: dict[int, type[GettyToolError]] = {
    400: BadSignatureError,
    401: NoPermissionError,
    403: NoPermissionError,
    404: AssetNotFoundError,
    410: AssetNotFoundError,
    429: RateLimitedError,
}


def error_from_status(status: int, detail: str | None = None) -> GettyToolError:
    """按 HTTP 状态码构造具体错误对象。5xx 统一走 UpstreamError。"""
    cls = HTTP_STATUS_MAP.get(status)
    if cls is None:
        cls = UpstreamError if 500 <= status < 600 else UnexpectedHttpError
    return cls(detail=detail, http_status=status)


# --------------------------------------------------------------------------
# 页面特征词：用于判断"这是个拦截/验证码页面"
# --------------------------------------------------------------------------

BLOCK_PAGE_MARKERS = [
    "cf-turnstile", "turnstile", "g-recaptcha", "recaptcha",
    "cf-chl", "challenge-platform", "just a moment",
    "attention required", "checking your browser",
    "verify you are human", "captcha",
]


def looks_like_block_page(text: str) -> str | None:
    """返回命中的拦截特征词，没命中返回 None。"""
    low = text[:20000].lower()
    for marker in BLOCK_PAGE_MARKERS:
        if marker in low:
            return marker
    return None
