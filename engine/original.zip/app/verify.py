# -*- coding: utf-8 -*-
"""
真实解码核验。

对应交接要求第 3、4 条：
    下载后必须真正解码文件，核对：是否为图片；图片格式；真实宽高；文件大小。
    避免把验证码页面或错误 HTML 保存为 JPG。
    界面显示真实像素尺寸，不要只显示含义不明确的"高清""2K""4K"。

核验流程（三道闸）：

  闸 1  魔数嗅探 —— 看文件头字节，判断"声称"是什么格式。
  闸 2  内容类型分流 —— 如果是 HTML/JSON/纯文本，直接判定为拦截页或错误页，
        并给出命中的拦截特征词（turnstile / recaptcha / cloudflare 等），
        绝不落盘成图片。
  闸 3  真解码 —— 用 Pillow 完整 load() 一遍（不是只看文件头），
        拿到真实 format / 像素尺寸 / 色彩模式；解码抛异常则判为损坏文件。

同时收集元数据段的"存在性"（EXIF / XMP / IPTC / ICC / Photoshop），
只报告有无与长度，不解析、不外传内容。
"""

from __future__ import annotations

import hashlib
import io
from dataclasses import dataclass, field

from .errors import (
    ImageDecodeFailedError,
    NotAnImageError,
    ResponseIsHtmlError,
    looks_like_block_page,
)

try:
    from PIL import Image
    _PIL_OK = True
except Exception:  # pragma: no cover
    Image = None
    _PIL_OK = False


# 魔数表：文件头 -> (格式名, 说明)
MAGIC_TABLE: list[tuple[bytes, str, str]] = [
    (b"\xff\xd8\xff", "JPEG", "JPEG 图片"),
    (b"\x89PNG\r\n\x1a\n", "PNG", "PNG 图片"),
    (b"GIF87a", "GIF", "GIF 图片"),
    (b"GIF89a", "GIF", "GIF 图片"),
    (b"BM", "BMP", "BMP 图片"),
    (b"II*\x00", "TIFF", "TIFF 图片（小端）"),
    (b"MM\x00*", "TIFF", "TIFF 图片（大端）"),
    (b"\x00\x00\x01\x00", "ICO", "ICO 图标"),
]

TEXTUAL_MARKERS = [
    (b"<!doctype html", "HTML"),
    (b"<!DOCTYPE html", "HTML"),
    (b"<html", "HTML"),
    (b"<?xml", "XML"),
    (b"{", "JSON/文本"),
    (b"[", "JSON/文本"),
]


def _guess_textual_kind(low: str) -> str:
    """按文本开头判断具体类型，用于报错时说清楚"拿到的是什么"。"""
    for marker, kind in TEXTUAL_MARKERS:
        if low.startswith(marker.decode("utf-8", "ignore").lower()):
            return kind
    return "文本"


@dataclass
class VerifyResult:
    """核验结论。全部字段都是实测得到的客观值。"""
    is_image: bool
    fmt: str = ""                 # 真实解码得到的格式，如 JPEG
    width: int = 0
    height: int = 0
    mode: str = ""                # RGB / RGBA / L / CMYK ...
    size_bytes: int = 0
    sha256: str = ""
    megapixels: float = 0.0
    aspect: float = 0.0
    aspect_label: str = ""
    orientation: str = ""
    metadata_segments: dict = field(default_factory=dict)
    magic_fmt: str = ""
    declared_content_type: str = ""
    content_sniff: str = ""       # 实际嗅探到的类型
    warnings: list[str] = field(default_factory=list)
    block_marker: str | None = None

    @property
    def format(self) -> str:
        """别名，方便外部按 dict 里的键名访问。"""
        return self.fmt

    @property
    def dimensions(self) -> str:
        return f"{self.width}×{self.height}" if self.is_image else ""

    @property
    def size_human(self) -> str:
        return human_size(self.size_bytes)

    def to_dict(self) -> dict:
        return {
            "is_image": self.is_image,
            "format": self.fmt,
            "width": self.width,
            "height": self.height,
            "dimensions": f"{self.width}×{self.height}" if self.is_image else "",
            "mode": self.mode,
            "size_bytes": self.size_bytes,
            "size_human": human_size(self.size_bytes),
            "sha256": self.sha256,
            "megapixels": round(self.megapixels, 2),
            "aspect": round(self.aspect, 4) if self.aspect else 0,
            "aspect_label": self.aspect_label,
            "orientation": self.orientation,
            "metadata_segments": self.metadata_segments,
            "magic_format": self.magic_fmt,
            "declared_content_type": self.declared_content_type,
            "content_sniff": self.content_sniff,
            "warnings": self.warnings,
        }


def human_size(n: int) -> str:
    if n < 1024:
        return f"{n} B"
    if n < 1024 * 1024:
        return f"{n / 1024:.1f} KB"
    return f"{n / 1024 / 1024:.2f} MB"


def sniff_magic(body: bytes) -> str:
    """按魔数判断格式。未命中返回空串。"""
    if len(body) >= 12 and body[0:4] == b"RIFF" and body[8:12] == b"WEBP":
        return "WEBP"
    if len(body) >= 12 and body[4:8] == b"ftyp":
        brand = body[8:12]
        if brand in (b"heic", b"heix", b"hevc", b"mif1", b"avif"):
            return "HEIF/AVIF"
        return "ISO-BMFF"
    for magic, name, _ in MAGIC_TABLE:
        if body.startswith(magic):
            return name
    return ""


def sniff_textual(body: bytes) -> str:
    """判断是否是可读文本（HTML / JSON / 纯文本）。"""
    head = body[:2048]
    # 含 NUL 字节基本可判定为二进制
    if b"\x00" in head[:512]:
        return ""
    try:
        text = head.decode("utf-8")
    except UnicodeDecodeError:
        try:
            text = head.decode("latin-1")
        except Exception:
            return ""
    stripped = text.lstrip()
    low = stripped[:400].lower()
    if low.startswith("<!doctype html") or low.startswith("<html"):
        return "HTML"
    if low.startswith("<?xml"):
        return "XML"
    if low.startswith("{") or low.startswith("["):
        return "JSON"
    # 可打印字符占比高 -> 纯文本
    printable = sum(1 for ch in text[:600] if ch.isprintable() or ch in "\r\n\t")
    if text and printable / max(len(text[:600]), 1) > 0.92:
        return "文本"
    return ""


def verify_image(body: bytes, *, declared_content_type: str = "") -> VerifyResult:
    """完整核验一段响应体。

    通过则返回 VerifyResult(is_image=True, ...)，
    失败则抛出 ResponseIsHtmlError / NotAnImageError / ImageDecodeFailedError。
    """
    if body is None or len(body) == 0:
        raise NotAnImageError("响应体为空（0 字节）。", detail="上游没有返回任何内容。")

    res = VerifyResult(
        is_image=False,
        size_bytes=len(body),
        sha256=hashlib.sha256(body).hexdigest(),
        declared_content_type=declared_content_type,
    )

    magic = sniff_magic(body)
    res.magic_fmt = magic
    textual = sniff_textual(body)
    res.content_sniff = magic or textual or "未知二进制"

    # ---------- 闸 2：文本内容一律不放行 ----------
    if not magic and textual:
        head_text = body[:20000].decode("utf-8", "ignore")
        marker = looks_like_block_page(head_text)
        if marker:
            res.block_marker = marker
            raise ResponseIsHtmlError(
                "上游返回的是人机验证 / 拦截页面，不是图片。",
                detail=f"命中拦截特征：{marker}\n"
                       f"内容类型声明：{declared_content_type or '(无)'}\n"
                       f"首行片段：{head_text.strip()[:180]}",
                content_type=declared_content_type,
                marker=marker,
            )
        raise ResponseIsHtmlError(
            f"上游返回的是 {textual} 内容，不是图片。",
            detail=f"内容类型声明：{declared_content_type or '(无)'}\n"
                   f"首行片段：{head_text.strip()[:180]}",
            content_type=declared_content_type,
        )

    if not magic:
        raise NotAnImageError(
            "响应既不是已知图片格式，也不是可识别的网页。",
            detail=f"内容类型声明：{declared_content_type or '(无)'}\n"
                   f"文件头 16 字节：{body[:16].hex(' ')}",
        )

    # ---------- 闸 3：真解码 ----------
    if not _PIL_OK:
        raise ImageDecodeFailedError(
            "缺少 Pillow，无法完成真实解码核验。",
            detail="请先安装依赖：pip install pillow",
        )

    try:
        probe = Image.open(io.BytesIO(body))
        probe.verify()                      # 结构完整性校验
        img = Image.open(io.BytesIO(body))  # verify() 后必须重新打开
        img.load()                          # 真正解码全部像素
    except Exception as exc:
        raise ImageDecodeFailedError(
            "文件头像是图片，但解码失败，文件可能被截断或损坏。",
            detail=f"魔数判定：{magic}\n解码异常：{type(exc).__name__}: {exc}",
        ) from exc

    res.is_image = True
    res.fmt = img.format or magic
    res.width, res.height = img.size
    if img.getexif().get(274) in (5,6,7,8):
        res.width, res.height = res.height, res.width
    res.mode = img.mode

    if res.width <= 0 or res.height <= 0:
        raise ImageDecodeFailedError(
            "解码得到的像素尺寸不合法。",
            detail=f"宽={res.width} 高={res.height}",
        )

    res.megapixels = res.width * res.height / 1_000_000
    res.aspect = res.width / res.height if res.height else 0.0
    if abs(res.aspect - 1.0) < 0.01:
        res.aspect_label = "正方形"
    elif res.aspect > 1.0:
        res.aspect_label = "横图"
    else:
        res.aspect_label = "竖图"
    res.orientation = res.aspect_label

    # 元数据段存在性（只报有无与长度）
    info = getattr(img, "info", {}) or {}
    segs: dict[str, int] = {}
    for key in ("exif", "xmp", "photoshop", "icc_profile", "iptc"):
        if key in info and info[key]:
            try:
                segs[key] = len(info[key])
            except Exception:
                segs[key] = -1
    res.metadata_segments = segs

    if not segs:
        res.warnings.append("未检测到 EXIF / XMP / IPTC 等元数据段。")

    # 长边提示（只陈述事实，不给"2K/4K"这类营销标签）
    long_edge = max(res.width, res.height)
    if long_edge < 600:
        res.warnings.append(f"长边仅 {long_edge} px，属于缩略图级别。")
    if res.fmt == "JPEG" and res.mode not in ("RGB", "L", "CMYK"):
        res.warnings.append(f"JPEG 色彩模式异常：{res.mode}")

    return res
