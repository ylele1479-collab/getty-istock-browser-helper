# -*- coding: utf-8 -*-
"""
Getty 链接识别与解析。

对应交接要求第 2 条：
    支持区分 Getty 素材详情页链接；media.gettyimages.com 图片直链。

实测确认的链接形态（2026-10 复核，素材 1292014419）：

  1) 图片直链（签名与尺寸绑定）
     https://media.gettyimages.com/id/1292014419/photo/xxx.jpg?s=2048x2048&w=gi&k=20&c=...
     实测四种情况：
       · s=/k=/c= 齐备              -> HTTP 200，返回该尺寸（2048×1363）
       · 只有 s=2048x2048，无 k=/c=  -> HTTP 400（签名与尺寸绑定，改尺寸必须换签名）
       · 完全不带任何参数            -> HTTP 200，返回默认尺寸（612×407）
       · w= 可省略，不属于签名本身

  2) 素材详情页
     https://www.gettyimages.com/detail/photo/xxx-royalty-free-image/1292014419
     https://www.gettyimages.ae/detail/photo/xxx-royalty-free-image/1927195976
     -> 返回 HTML，页面内嵌多档带签名的 media 图源（最高 s=2048x2048）

  3) 详情页里的媒体路径
     https://media.gettyimages.com/id/1292014419/photo/xxx.jpg?s=1024x1024
"""

from __future__ import annotations

import html as html_mod
import re
import urllib.parse
from dataclasses import dataclass, field

from .errors import AssetIdMissingError, InvalidUrlError, UnsupportedHostError
from .netguard import is_allowed_host

# 数字编号及旧素材的字母前缀或数字后缀编号（如 dv1274111、200123056-001）。
ASSET_ID_PATTERN = r"(?:[A-Za-z]{1,4})?[0-9]{6,12}(?:-[0-9]{1,4})?"
DETAIL_ID_RE = re.compile(r"/(" + ASSET_ID_PATTERN + r")(?:[/?#]|$)")

# media 直链路径里的编号
MEDIA_ID_RE = re.compile(r"/id/(" + ASSET_ID_PATTERN + r")(?:/|$)", re.I)

# 详情页里内嵌的 media 图源
EMBED_MEDIA_RE = re.compile(
    r"https://media\.gettyimages\.com/[^\s\"'<>\\]+?\.(?:jpg|jpeg|png|webp)"
    r"(?:\?[^\s\"'<>\\]*)?",
    re.I,
)

# s= 参数声明的尺寸。
# 注意：urlsplit(...).query 不含前导 '?'，所以必须同时接受"字符串开头"。
SIZE_PARAM_RE = re.compile(r"(?:^|[?&])s=(\d{2,5})x(\d{2,5})")
SIZE_TOKEN_RE = re.compile(r"(?:^|[?&])s=([0-9a-f]{5,10})(?:&|$)")

# 已知的 s= 尺寸别名（Getty 内部代号），用于按"声明尺寸"排序
KNOWN_SIZE_TOKENS = {
    "170667a": 510,     # 实测 510x339
    "612x612": 612,
    "1024x1024": 1024,
    "2048x2048": 2048,
    "170x170": 170,
}

KIND_DIRECT_LINK = "direct_link"      # media.gettyimages.com 直链
KIND_DETAIL_PAGE = "detail_page"      # www.gettyimages.* 素材详情页
KIND_UNKNOWN = "unknown"


@dataclass
class GettyRef:
    """一个被识别出来的 Getty 引用。"""
    raw: str
    kind: str
    asset_id: str | None = None
    host: str = ""
    scheme: str = ""
    is_signed: bool = False          # 直链是否带完整签名
    declared_size: int | None = None  # s= 声明的长边
    path_ext: str = ""               # jpg / webp
    watermark_param: str = ""        # w= 的取值（"0" = 无水印变体）
    provider: str = "getty"

    def to_dict(self) -> dict:
        return {
            "raw": self.raw,
            "kind": self.kind,
            "asset_id": self.asset_id,
            "host": self.host,
            "scheme": self.scheme,
            "is_signed": self.is_signed,
            "declared_size": self.declared_size,
            "path_ext": self.path_ext,
            "watermark_param": self.watermark_param,
            "provider": self.provider,
        }


@dataclass
class CandidateSource:
    """详情页里挖出来的一个候选图源。"""
    url: str
    fmt: str = ""
    declared_size: int | None = None
    signature_present: bool = False
    watermark_param: str = ""     # w=gi / w=0
    rank: int = 0
    notes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "url": self.url,
            "fmt": self.fmt,
            "declared_size": self.declared_size,
            "signature_present": self.signature_present,
            "watermark_param": self.watermark_param,
            "rank": self.rank,
            "notes": self.notes,
        }


# --------------------------------------------------------------------------
# 识别
# --------------------------------------------------------------------------

def identify(url: str) -> GettyRef:
    """识别一条输入链接属于哪种形态。不做网络请求。"""
    if not url or not isinstance(url, str):
        raise InvalidUrlError("链接为空。")

    raw = url.strip().strip("<>\"'` ")
    try:
        p = urllib.parse.urlsplit(raw)
    except Exception as exc:
        raise InvalidUrlError("链接无法解析。", detail=str(exc)) from exc

    host = (p.hostname or "").lower()
    if not host:
        raise InvalidUrlError("链接里没有主机名。")
    if not is_allowed_host(host):
        raise UnsupportedHostError(
            f"不支持的主机：{host}",
            detail="只接受 Getty 或 iStock 的官方素材页和图片地址。",
        )

    path = p.path or ""
    query = p.query or ""
    ext = ""
    m = re.search(r"\.(jpg|jpeg|png|webp)$", path, re.I)
    if m:
        ext = m.group(1).lower()

    ref = GettyRef(raw=raw, kind=KIND_UNKNOWN, host=host,
                   scheme=(p.scheme or "").lower(), path_ext=ext)

    if host in ("media.istockphoto.com", "www.istockphoto.com", "istockphoto.com"):
        ref.provider = "istock"
        if host == "media.istockphoto.com":
            ref.kind = KIND_DIRECT_LINK
            match = MEDIA_ID_RE.search(path)
            if not match:
                raise AssetIdMissingError("iStock 图片直链缺少 /id/素材编号/。")
            ref.asset_id = match.group(1)
            ref.is_signed = _has_full_signature(query)
            ref.declared_size = _parse_declared_size(query)
            ref.watermark_param = _watermark_param(query)
            return ref
        # iStock detail URLs contain gm<asset>-<page id>; the latter is not the photo ID.
        match = re.search(r"-gm([0-9]{6,12})-[0-9]+(?:/|$)", path, re.I)
        if not match:
            raise AssetIdMissingError("请复制 iStock 单张照片详情页，或 media.istockphoto.com 图片直链。")
        ref.kind = KIND_DETAIL_PAGE
        ref.asset_id = match.group(1)
        return ref

    # --- media 图床直链 ---
    if host.startswith("media.") or host.startswith("embed."):
        ref.kind = KIND_DIRECT_LINK
        mid = MEDIA_ID_RE.search(path)
        if mid:
            ref.asset_id = mid.group(1)
        ref.is_signed = _has_full_signature(query)
        ref.declared_size = _parse_declared_size(query)
        ref.watermark_param = _watermark_param(query)
        return ref

    # --- 详情页：必须有 /detail/ 且包含完整素材编号 ---
    if "/detail/" in path:
        ref.kind = KIND_DETAIL_PAGE
        did = DETAIL_ID_RE.search(path)
        if not did:
            raise AssetIdMissingError(
                "这条链接是素材详情页，但末尾没有素材编号。",
                detail=(
                    f"链接：{raw}\n"
                    "正确的详情页链接形如：\n"
                    "  https://www.gettyimages.com/detail/photo/xxx-royalty-free-image/1292014419\n"
                    "请打开具体素材页面后再复制地址栏链接。"
                ),
            )
        ref.asset_id = did.group(1)
        return ref

    # --- 明确的列表 / 搜索 / 集合页：直接拒绝，不要静默返回随机图 ---
    listing_markers = {
        "/photos/": "图片搜索结果页",
        "/search/": "搜索页",
        "/collections/": "集合页",
        "/videos/": "视频列表页",
        "/music/": "音乐列表页",
        "/editorial-images/": "编辑类图片列表页",
        "/creative-images/": "创意图片列表页",
        "/images/": "图片列表页",
    }
    for marker, label in listing_markers.items():
        if marker in path:
            raise AssetIdMissingError(
                f"这是一张{label}，不是单个素材页。",
                detail=(
                    f"链接：{raw}\n"
                    f"命中列表页特征：{marker}\n"
                    "列表页里含有很多张图，工具无法判断你要哪一张。"
                    "如果按列表页处理，会返回一张随机图片——那没有意义，所以这里直接拒绝。\n"
                    "正确做法：在 Getty 上点开你真正想要的那张图，进入素材详情页后，"
                    "复制地址栏里包含 /detail/、以素材编号结尾的链接。"
                ),
            )

    # --- 其他 gettyimages 路径：按编号兜底 ---
    any_id = DETAIL_ID_RE.search(path) or MEDIA_ID_RE.search(path)
    if any_id:
        ref.asset_id = any_id.group(1)
        ref.kind = KIND_DETAIL_PAGE
        return ref

    raise AssetIdMissingError(
        "无法从这条链接里识别出素材编号。",
        detail=(
            f"链接：{raw}\n"
            "本工具接受两种链接：\n"
            "  1) media.gettyimages.com 的图片直链（带 s=/k=/c= 参数）\n"
            "  2) www.gettyimages.com/detail/... 的素材详情页链接（结尾是素材编号）\n"
            "请确认你复制的是具体某一张图的链接，而不是首页或搜索结果页。"
        ),
    )


def _has_full_signature(query: str) -> bool:
    """签名是否完整。

    实测确认：s=（尺寸）、k=（key id）、c=（签名值）三者齐备才是有效请求；
    缺少或改动任何一个都会被服务端以 HTTP 400 拒绝。
    w= 是水印/样式开关，不属于签名本身，故不强制要求。
    """
    q = (query or "").lower()
    return ("s=" in q) and ("k=" in q) and ("c=" in q)


def _parse_declared_size(query: str) -> int | None:
    """解析 s= 参数声明的长边像素。"""
    m = SIZE_PARAM_RE.search(query)
    if m:
        return max(int(m.group(1)), int(m.group(2)))
    m2 = SIZE_TOKEN_RE.search(query)
    if m2 and m2.group(1) in KNOWN_SIZE_TOKENS:
        return KNOWN_SIZE_TOKENS[m2.group(1)]
    return None


# --------------------------------------------------------------------------
# 详情页解析
# --------------------------------------------------------------------------

def build_detail_url(asset_id: str, host: str = "www.gettyimages.com") -> str:
    """把素材编号拼成详情页链接。slug 部分 Getty 不校验，可省略。"""
    return f"https://{host}/detail/photo/-/{asset_id}"


def extract_candidates(page_html: str, *, provider: str = 'getty') -> list[CandidateSource]:
    """从详情页 HTML 里挖出所有内嵌的 media 图源，按声明尺寸降序排列。"""
    found: dict[str, CandidateSource] = {}

    pattern = (EMBED_MEDIA_RE if provider == 'getty' else re.compile(
        r"https://media\.istockphoto\.com/[^\s\"'<>\\]+?\.(?:jpg|jpeg|png|webp)(?:\?[^\s\"'<>\\]*)?", re.I))
    for m in pattern.finditer(page_html):
        u = html_mod.unescape(m.group(0)).strip()
        u = u.rstrip(")").rstrip(",").rstrip(";")
        if u.endswith("&amp;"):
            u = u[:-5]
        if u in found:
            continue

        p = urllib.parse.urlsplit(u)
        q = p.query
        ext = ""
        me = re.search(r"\.(jpg|jpeg|png|webp)$", p.path, re.I)
        if me:
            ext = me.group(1).lower()

        cand = CandidateSource(
            url=u,
            fmt=ext,
            declared_size=_parse_declared_size(q),
            signature_present=_has_full_signature(q),
            watermark_param=_watermark_param(q),
        )
        if not cand.signature_present:
            cand.notes.append("无完整签名，实测会返回 400")
        found[u] = cand

    # 排序：签名完整优先 -> 声明尺寸大优先 -> jpg 优先于 webp
    def sort_key(c: CandidateSource):
        return (
            0 if c.signature_present else 1,
            -(c.declared_size or 0),
            0 if c.fmt in ("jpg", "jpeg") else 1,
        )

    ordered = sorted(found.values(), key=sort_key)
    for i, c in enumerate(ordered):
        c.rank = i
    return ordered


def _watermark_param(query: str) -> str:
    m = re.search(r"(?:^|[?&])w=([^&]+)", query or "")
    return m.group(1) if m else ""


# --------------------------------------------------------------------------
# 无水印变体
#
# 实测结论（2026-10-08 复核，两个素材各档逐一目视核对）：
#     w=0   -> 无水印干净图，详情页只在 612 与 510 两档提供
#     w=gi  -> 带水印 comp，详情页在 2048 / 1024 / 612 / 510 都提供
#
#   素材 1292014419：?s=612x612&w=0&... -> 612×407 完全无 gettyimages 标识、
#                    无 Credit 署名、无左下角编号（已目视确认）
#   素材 78015698  ：?s=170667a&w=0&... -> 337×506 同样干净
#
# 注意：c= 签名与 s=/w= 绑定，把 w=gi 改成 w=0 会被服务端以 400 拒绝，
# 所以只能使用详情页已经公开给出的 w=0 地址，不能自行拼参数。
# --------------------------------------------------------------------------

CLEAN_WATERMARK_VALUE = "0"


def is_clean_variant(cand) -> bool:
    """该候选/引用是否是无水印变体（w=0）。

    对 CandidateSource 和 GettyRef 都适用——两者都有 watermark_param 字段。
    """
    return (getattr(cand, "watermark_param", "") or "").strip() == CLEAN_WATERMARK_VALUE


def order_candidates(candidates: list["CandidateSource"],
                     prefer_clean: bool = True) -> list["CandidateSource"]:
    """按优先级排列候选。

    prefer_clean=True 时：先排所有无水印变体（按声明尺寸降序），
    再排带水印变体（按声明尺寸降序）。
    这样默认会拿到「公开可得的最大无水印图」，
    拿不到才退回到「最大分辨率 + 去水印」这条路。
    """
    signed = [c for c in candidates if c.signature_present] or list(candidates)

    def by_size(items):
        return sorted(items, key=lambda c: -(c.declared_size or 0))

    if not prefer_clean:
        return by_size(signed)

    clean = [c for c in signed if is_clean_variant(c)]
    marked = [c for c in signed if not is_clean_variant(c)]
    return by_size(clean) + by_size(marked)
