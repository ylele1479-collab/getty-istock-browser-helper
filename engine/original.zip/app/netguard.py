# -*- coding: utf-8 -*-
"""
安全抓取层（SSRF 防护 + 代理感知）。

对应交接要求第 7 条：
    下载功能需要限制输入 URL 的协议、主机和重定向目标。
    如果部署为服务端网页，要防止用户输入指向本地网络或服务器内部资源的地址。

--------------------------------------------------------------------
防护模型
--------------------------------------------------------------------

主防线（任何模式下都强制执行，不可关闭）：
  1. 协议白名单：只允许 http / https。
  2. 端口白名单：只允许 80 / 443。
  3. 主机白名单：gettyimages 主站、regional 域名、media 图床、api 域名。
     这一条才是真正的 SSRF 主防线——用户输入不可能指向内网。
  4. 重定向不自动跟随：逐跳重新走 1~3，超限即停，绝不无限重试。
  5. 体积上限：边读边计数，超限立即断开。

纵深防线（IP 层校验，两种模式行为不同）：
  · 直连模式：把域名解析成 IP，逐个判定，命中回环 / 私网 / 链路本地 /
    保留 / 组播 / 未指定一律阻断；连接时做 DNS 固定（连已校验的 IP，
    SNI 仍用域名），防止 DNS rebinding。这是最强的一档。
  · 代理模式：本机配置了 HTTP 代理时（企业代理、Clash / mihomo / sing-box
    的 TUN + fake-IP 等），DNS 会返回 198.18.0.0/15 这类"假 IP"，
    真实解析由代理完成。此时 IP 校验会误伤正常流量。
    因此代理模式下：已知 fake-IP 段放行，但会在结果里明确标注
    "IP 校验已降级"，绝不假装做了严格校验。
    真正的私网 / 回环地址（如 192.168.x、127.0.0.1）在两种模式下都照样阻断。

可用环境变量控制：
  GETTY_NET_MODE   auto（默认）| direct | proxy
  GETTY_STRICT_IP  1 时强制严格 IP 校验（服务端部署建议开启）
  HTTP_PROXY / HTTPS_PROXY / ALL_PROXY  标准代理变量，自动识别
--------------------------------------------------------------------
"""

from __future__ import annotations

import http.client
import ipaddress
import os
import re
import socket
import ssl
import urllib.parse
from dataclasses import dataclass, field

from .errors import (
    BlockedPrivateTargetError,
    BlockedRedirectError,
    DnsFailedError,
    InvalidUrlError,
    NetworkError,
    ResponseTooLargeError,
    TimeoutError_,
    TooManyRedirectsError,
    UnsupportedHostError,
    UnsupportedSchemeError,
    error_from_status,
)

# --------------------------------------------------------------------------
# 主机白名单
# --------------------------------------------------------------------------

ALLOWED_SCHEMES = {"http", "https"}
ALLOWED_PORTS = {80, 443}

ALLOWED_EXACT_HOSTS = {
    "istockphoto.com",
    "www.istockphoto.com",
    "media.istockphoto.com",
    "gettyimages.com",
    "www.gettyimages.com",
    "media.gettyimages.com",
    "api.gettyimages.com",
    "embed.gettyimages.com",
    "short.askingtips.com",
}

REGIONAL_RE = r"^gettyimages\.[a-z]{2,3}(\.[a-z]{2})?$"
REGIONAL_HOSTS = {
    "gettyimages.ae", "gettyimages.co.uk", "gettyimages.de", "gettyimages.fr",
    "gettyimages.es", "gettyimages.it", "gettyimages.jp", "gettyimages.com.br",
    "gettyimages.com.au", "gettyimages.ca", "gettyimages.in", "gettyimages.cn",
    "gettyimages.nl", "gettyimages.se", "gettyimages.pl", "gettyimages.mx",
    "gettyimages.com.mx", "gettyimages.co.jp", "gettyimages.com.hk",
    "gettyimages.com.sg", "gettyimages.pt", "gettyimages.ru", "gettyimages.ch",
    "gettyimages.at", "gettyimages.be", "gettyimages.dk", "gettyimages.no",
    "gettyimages.fi", "gettyimages.gr", "gettyimages.tr", "gettyimages.co.kr",
    "gettyimages.hk", "gettyimages.co.nz", "gettyimages.co.za", "gettyimages.ie", "gettyimages.tw",
}

# 已知的本地代理 fake-IP 段
FAKE_IP_NETS = ["198.18.0.0/15", "198.19.0.0/16"]

# 任何情况下都硬阻断的网段
HARD_BLOCK_NETS = [
    "169.254.0.0/16",      # 云元数据 169.254.169.254
    "100.64.0.0/10",       # CGNAT
    "192.0.0.0/24",
    "0.0.0.0/8",
    "::/128",
    "fc00::/7",
    "fe80::/10",
]

DEFAULT_MAX_BYTES = 40 * 1024 * 1024
DEFAULT_TIMEOUT = 30
DEFAULT_MAX_REDIRECTS = 5

DEFAULT_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
    ),
    "Accept": "image/avif,image/webp,image/jpeg,image/png,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Accept-Encoding": "identity",
}


# --------------------------------------------------------------------------
# 网络策略
# --------------------------------------------------------------------------

def _env(*names: str) -> str:
    for n in names:
        v = os.environ.get(n)
        if v:
            return v.strip()
    return ""


def _human_size(n: int) -> str:
    """把字节数写成人话。避免出现「超过 0 MB 上限」这种读不懂的提示。"""
    n = int(n)
    if n < 1024:
        return f"{n} 字节"
    if n < 1024 * 1024:
        return f"{n / 1024:.0f} KB"
    return f"{n / 1024 / 1024:.1f} MB"


def detect_proxy() -> tuple[str, int] | None:
    """从环境变量识别 HTTP 代理。"""
    raw = _env("HTTPS_PROXY", "https_proxy", "ALL_PROXY", "all_proxy",
               "HTTP_PROXY", "http_proxy")
    if not raw:
        return None
    if "://" not in raw:
        raw = "http://" + raw
    try:
        p = urllib.parse.urlsplit(raw)
        host = p.hostname or ""
        port = p.port or (443 if p.scheme == "https" else 80)
        if host:
            return host, port
    except Exception:
        return None
    return None


@dataclass
class NetPolicy:
    """一次请求使用的网络策略。"""
    mode: str = "direct"                 # direct | proxy（决定连接方式）
    proxy: tuple[str, int] | None = None
    strict_ip: bool = False              # 是否强制严格 IP 校验
    allow_fakeip: bool = True            # 是否放行本地代理的 fake-IP 段
    notes: list[str] = field(default_factory=list)
    ip_check_relaxed: bool = False

    def describe(self) -> str:
        if self.mode == "proxy":
            ph, pp = self.proxy or ("?", 0)
            base = f"经本地代理 {ph}:{pp}"
        else:
            base = "直连（DNS 固定）"
        return base + ("，IP 校验：严格" if self.strict_ip else "，IP 校验：允许 fake-IP")


def resolve_policy() -> NetPolicy:
    """按环境变量决定网络策略。

    关于 fake-IP 的重要说明（实测结论，别改错）：
        本机若处于 Clash / mihomo / sing-box 的 TUN + fake-IP 环境，
        所有域名都会解析到 198.18.0.0/15 这类保留段。

        关键在于：**这种环境下即使没有任何 *_proxy 环境变量，连接依然能通**——
        因为 TUN 虚拟网卡在 IP 层接管了路由，不需要应用层知道代理的存在。
        实测：不带代理变量时裸 TCP 连 198.18.0.109:443 成功，
        TLS 握手返回的证书 CN 正是 media.gettyimages.com。

        所以判断依据不能是「有没有代理环境变量」，而应当是
        「解析结果是否落在已知 fake-IP 段」——这才是 fake-IP 环境本身的可观测特征。
        只按环境变量判断的话，用户双击 run.bat 启动（没有代理变量）时，
        所有正常请求都会被 IP 校验误拦成「内网地址」。

    真正的 SSRF 主防线始终是**主机白名单**：用户输入不可能指向内网。
    IP 层校验只是纵深防御，放行 fake-IP 不会削弱主防线。
    """
    mode_env = _env("GETTY_NET_MODE").lower()
    strict_env = _env("GETTY_STRICT_IP") == "1"
    proxy = detect_proxy()

    pol = NetPolicy(
        mode="proxy" if proxy else "direct",
        proxy=proxy,
        strict_ip=strict_env,
        allow_fakeip=not strict_env,
    )

    if mode_env == "direct":
        pol.mode = "direct"
        pol.proxy = None
        pol.notes.append("GETTY_NET_MODE=direct：强制直连，不做代理转发。")
    elif mode_env == "proxy" and proxy:
        pol.notes.append(f"GETTY_NET_MODE=proxy：经代理 {proxy[0]}:{proxy[1]}。")
    elif proxy:
        pol.notes.append(f"检测到本地代理 {proxy[0]}:{proxy[1]}。")

    if strict_env:
        pol.notes.append("GETTY_STRICT_IP=1：强制严格 IP 校验，fake-IP 段会被阻断。")
    else:
        pol.notes.append(
            "IP 校验策略：公网地址放行；已知 fake-IP 段（198.18.0.0/15 等）也放行，"
            "因为那是本机代理在 IP 层接管的特征，真实解析由代理完成。"
            "SSRF 主防线由主机白名单强制保证，不受影响。"
        )

    return pol


# --------------------------------------------------------------------------
# 主机 / IP 校验
# --------------------------------------------------------------------------

def is_allowed_host(host: str) -> bool:
    h = (host or "").strip().lower().rstrip(".")
    if not h:
        return False
    if h in ALLOWED_EXACT_HOSTS or h in REGIONAL_HOSTS:
        return True
    if h.endswith(".gettyimages.com"):
        return True
    parts = h.split(".")
    if len(parts) >= 3:
        parent = ".".join(parts[-2:])
        grand = ".".join(parts[-3:])
        if parent in REGIONAL_HOSTS or grand in REGIONAL_HOSTS:
            return True
    return bool(re.match(REGIONAL_RE, h))


def is_public_ip(ip_str: str) -> tuple[bool, str]:
    """判断 IP 是否为公网可访问地址。返回 (是否公网, 原因)。"""
    try:
        ip = ipaddress.ip_address(ip_str)
    except ValueError:
        return False, f"无法解析为 IP：{ip_str}"

    for flag, reason in [
        (ip.is_loopback, "回环地址"),
        (ip.is_private, "私有网段"),
        (ip.is_link_local, "链路本地地址"),
        (ip.is_multicast, "组播地址"),
        (ip.is_reserved, "保留地址"),
        (ip.is_unspecified, "未指定地址"),
    ]:
        if flag:
            return False, reason

    for net in HARD_BLOCK_NETS:
        try:
            if ip in ipaddress.ip_network(net):
                return False, f"命中受限网段 {net}"
        except ValueError:
            continue
    return True, ""


def is_fake_ip(ip_str: str) -> bool:
    """是否落在已知的本地代理 fake-IP 段。"""
    try:
        ip = ipaddress.ip_address(ip_str)
    except ValueError:
        return False
    for net in FAKE_IP_NETS:
        try:
            if ip in ipaddress.ip_network(net):
                return True
        except ValueError:
            continue
    return False


@dataclass
class ValidatedTarget:
    url: str
    scheme: str
    host: str
    port: int
    path: str
    ips: list[str] = field(default_factory=list)
    ip_relaxed: bool = False
    ip_note: str = ""


def validate_url(url: str, policy: NetPolicy | None = None,
                 *, allow_http: bool = True) -> ValidatedTarget:
    """对 URL 做协议 / 端口 / 主机 / DNS / IP 全套校验。"""
    policy = policy or resolve_policy()

    if not url or not isinstance(url, str):
        raise InvalidUrlError("链接为空。")

    url = url.strip().replace("\n", "").replace("\r", "").replace("\t", "")
    url = url.strip("<>\"'` ")

    try:
        parsed = urllib.parse.urlsplit(url)
    except Exception as exc:
        raise InvalidUrlError("链接无法解析。", detail=str(exc)) from exc

    scheme = (parsed.scheme or "").lower()
    if not scheme:
        raise InvalidUrlError("链接缺少协议头。",
                              detail="请使用以 http:// 或 https:// 开头的完整链接。")
    if scheme not in ALLOWED_SCHEMES:
        raise UnsupportedSchemeError(f"协议 {scheme}: 不被允许。",
                                     detail="只接受 http 与 https。")
    if scheme == "http" and not allow_http:
        raise UnsupportedSchemeError("出于安全考虑，已禁用明文 http 抓取。")

    host = (parsed.hostname or "").lower()
    if not host:
        raise InvalidUrlError("链接里没有主机名。")

    if not is_allowed_host(host):
        raise UnsupportedHostError(
            f"不支持的主机：{host}",
            detail="本工具只抓取 gettyimages.com 主站、其 regional 域名、"
                   "media.gettyimages.com 图床与 api.gettyimages.com。"
                   "这一条是 SSRF 的主防线，任何内网地址都会被它挡住。",
        )

    if host == "short.askingtips.com" and (
        scheme != "https" or not parsed.path.startswith("/uploads/") or parsed.query
        or not re.search(r"\.(jpg|jpeg|png|webp)$", parsed.path, re.I)
    ):
        raise UnsupportedHostError("这里只支持第三方返回的最终图片直链，不支持广告跳转或下载任务地址。")

    port = parsed.port
    if port is None:
        port = 443 if scheme == "https" else 80
    if port not in ALLOWED_PORTS:
        raise UnsupportedHostError(f"端口 {port} 不被允许。", detail="只允许 80 与 443。")

    # --- DNS 解析 ---
    try:
        infos = socket.getaddrinfo(host, port, proto=socket.IPPROTO_TCP)
    except socket.gaierror as exc:
        raise DnsFailedError(f"无法解析域名 {host}", detail=str(exc)) from exc

    ips: list[str] = []
    for info in infos:
        ip = info[4][0]
        if ip not in ips:
            ips.append(ip)

    if not ips:
        raise DnsFailedError(f"域名 {host} 没有解析到任何地址。")

    # --- IP 校验 ---
    relaxed = False
    note = ""
    for ip in ips:
        ok, reason = is_public_ip(ip)
        if ok:
            continue
        # 放行已知 fake-IP 段。
        # 注意这里**不看**有没有代理环境变量——fake-IP 段本身就是
        # 「本机处于 fake-IP 代理环境」的可观测特征，而 TUN 会在 IP 层接管路由，
        # 即使没有 *_proxy 环境变量也照样能连通（已实测）。
        # 只按环境变量判断的话，双击 run.bat 启动（无代理变量）时
        # 所有正常请求都会被误拦成「内网地址」。
        if policy.allow_fakeip and is_fake_ip(ip):
            relaxed = True
            note = (f"该地址 {ip} 落在本地代理的 fake-IP 段（本机 TUN 在 IP 层接管路由），"
                    f"真实解析由代理完成，IP 层校验已降级。"
                    f"SSRF 主防线仍由主机白名单保证。")
            continue
        raise BlockedPrivateTargetError(
            f"{host} 解析到了非公网地址（{reason}）。",
            detail=(
                f"命中 IP：{ip}。已按 SSRF 防护规则阻断。\n"
                + ("（当前为 GETTY_STRICT_IP=1 严格模式，fake-IP 段也会被阻断。"
                   "如果你本机确实在用 Clash 一类的 fake-IP 代理，"
                   "去掉该环境变量即可正常使用。）"
                   if policy.strict_ip and is_fake_ip(ip) else "")
            ),
        )

    path = parsed.path or "/"
    if parsed.query:
        path += "?" + parsed.query

    return ValidatedTarget(url=url, scheme=scheme, host=host, port=port,
                           path=path, ips=ips, ip_relaxed=relaxed, ip_note=note)


# --------------------------------------------------------------------------
# 连接实现
# --------------------------------------------------------------------------

class _PinnedHTTPSConnection(http.client.HTTPSConnection):
    """直连模式：连已校验的 IP，SNI 与证书校验仍使用原始域名（防 DNS rebinding）。"""

    def __init__(self, host: str, pin_ip: str, **kwargs):
        super().__init__(host, **kwargs)
        self._pin_ip = pin_ip

    def connect(self):
        sock = socket.create_connection(
            (self._pin_ip, self.port), self.timeout, self.source_address)
        if self._tunnel_host:
            self.sock = sock
            self._tunnel()
        ctx = self._context or ssl.create_default_context()
        self.sock = ctx.wrap_socket(sock, server_hostname=self.host)


class _PinnedHTTPConnection(http.client.HTTPConnection):
    """直连模式的明文 http。"""

    def __init__(self, host: str, pin_ip: str, **kwargs):
        super().__init__(host, **kwargs)
        self._pin_ip = pin_ip

    def connect(self):
        self.sock = socket.create_connection(
            (self._pin_ip, self.port), self.timeout, self.source_address)


class _ProxyHTTPSConnection(http.client.HTTPSConnection):
    """代理模式：先连代理，用 CONNECT 打隧道，再做 TLS（SNI 用真实域名）。"""

    def __init__(self, host: str, proxy: tuple[str, int], **kwargs):
        super().__init__(host, **kwargs)
        self._proxy = proxy

    def connect(self):
        ph, pp = self._proxy
        sock = socket.create_connection((ph, pp), self.timeout)
        self.sock = sock
        self._tunnel_host = self.host
        self._tunnel_port = self.port
        self._tunnel()
        ctx = self._context or ssl.create_default_context()
        self.sock = ctx.wrap_socket(self.sock, server_hostname=self.host)


class _ProxyHTTPConnection(http.client.HTTPConnection):
    """代理模式的明文 http：请求行用绝对 URI。"""

    def __init__(self, host: str, proxy: tuple[str, int], **kwargs):
        super().__init__(host, **kwargs)
        self._proxy = proxy

    def connect(self):
        ph, pp = self._proxy
        self.sock = socket.create_connection((ph, pp), self.timeout)


# --------------------------------------------------------------------------
# 抓取
# --------------------------------------------------------------------------

@dataclass
class FetchResult:
    ok: bool
    url: str
    status: int
    content_type: str
    body: bytes
    headers: dict
    redirect_chain: list[str] = field(default_factory=list)
    resolved_ips: list[str] = field(default_factory=list)
    net_mode: str = ""
    net_note: str = ""
    ip_check_relaxed: bool = False

    @property
    def size(self) -> int:
        return len(self.body)

    @property
    def sha256(self) -> str:
        import hashlib
        return hashlib.sha256(self.body).hexdigest()


def fetch(url: str, *,
          max_bytes: int = DEFAULT_MAX_BYTES,
          timeout: float = DEFAULT_TIMEOUT,
          max_redirects: int = DEFAULT_MAX_REDIRECTS,
          headers: dict | None = None,
          method: str = "GET",
          body: bytes | None = None,
          allow_http: bool = True,
          policy: NetPolicy | None = None) -> FetchResult:
    """安全抓取：逐跳校验 + 体积上限 + 代理感知。"""
    policy = policy or resolve_policy()
    chain: list[str] = []
    current = url
    hdrs = dict(DEFAULT_HEADERS)
    if headers:
        hdrs.update(headers)

    for _hop in range(max_redirects + 1):
        target = validate_url(current, policy, allow_http=allow_http)

        if policy.mode == "proxy" and policy.proxy:
            ph, pp = policy.proxy
            if target.scheme == "https":
                conn = _ProxyHTTPSConnection(target.host, (ph, pp),
                                             port=target.port, timeout=timeout)
                req_path = target.path
            else:
                conn = _ProxyHTTPConnection(target.host, (ph, pp),
                                            port=target.port, timeout=timeout)
                # 明文 http 经代理时使用绝对 URI
                req_path = f"http://{target.host}:{target.port}{target.path}"
        else:
            pin_ip = next((i for i in target.ips if ":" not in i), target.ips[0])
            if target.scheme == "https":
                conn = _PinnedHTTPSConnection(target.host, pin_ip,
                                              port=target.port, timeout=timeout)
            else:
                conn = _PinnedHTTPConnection(target.host, pin_ip,
                                             port=target.port, timeout=timeout)
            req_path = target.path

        try:
            conn.request(method, req_path, body=body, headers=hdrs)
            resp = conn.getresponse()
        except socket.timeout as exc:
            raise TimeoutError_(f"请求超时（{timeout} 秒）。", detail=str(exc)) from exc
        except ssl.SSLError as exc:
            raise NetworkError("TLS 握手失败。", detail=str(exc)) from exc
        except socket.gaierror as exc:
            raise DnsFailedError("域名解析失败。", detail=str(exc)) from exc
        except OSError as exc:
            raise NetworkError("网络连接失败。", detail=str(exc)) from exc

        # --- 重定向：手动逐跳校验 ---
        if resp.status in (301, 302, 303, 307, 308):
            location = resp.getheader("Location")
            resp.read()
            conn.close()
            if not location:
                raise BlockedRedirectError(
                    f"上游返回 {resp.status} 但没有 Location 头。",
                    http_status=resp.status)
            nxt = urllib.parse.urljoin(current, location)
            chain.append(current)
            if len(chain) > max_redirects:
                raise TooManyRedirectsError(
                    f"重定向次数超过 {max_redirects} 次，已停止。",
                    detail=" → ".join(chain[-6:]))
            try:
                validate_url(nxt, policy, allow_http=allow_http)
            except (UnsupportedHostError, BlockedPrivateTargetError) as exc:
                raise BlockedRedirectError(
                    "重定向目标不在允许范围内，已阻断。",
                    detail=f"原始目标：{current}\n跳转目标：{nxt}\n原因：{exc.message}",
                ) from exc
            current = nxt
            continue

        # --- 非 2xx ---
        if not (200 <= resp.status < 300):
            raw = resp.read(4096)
            conn.close()
            snippet = raw[:400].decode("utf-8", "ignore")
            err = error_from_status(resp.status, detail=snippet or None)
            if resp.status == 400 and "media.gettyimages.com" in target.host:
                err.message = (
                    "签名与请求参数不匹配（HTTP 400）。"
                    "media.gettyimages.com 的 c= 签名与 s= 尺寸是绑定的："
                    "请求里带了 s= 却没有配套的 k=/c=，就会被拒绝。"
                    "改用素材详情页链接可以自动取到页面内嵌的合法签名地址。"
                )
            raise err

        # --- 边读边计数 ---
        chunks: list[bytes] = []
        total = 0
        try:
            while True:
                chunk = resp.read(65536)
                if not chunk:
                    break
                total += len(chunk)
                if total > max_bytes:
                    conn.close()
                    raise ResponseTooLargeError(
                        f"文件超过 {_human_size(max_bytes)} 上限，已中止。",
                        detail=f"已读取 {_human_size(total)}。"
                               "如果确实需要更大的文件，可调高 max_bytes 参数。")
                chunks.append(chunk)
        except socket.timeout as exc:
            conn.close()
            raise TimeoutError_("读取响应体超时。", detail=str(exc)) from exc
        finally:
            try:
                conn.close()
            except Exception:
                pass

        return FetchResult(
            ok=True,
            url=current,
            status=resp.status,
            content_type=resp.getheader("Content-Type", "") or "",
            body=b"".join(chunks),
            headers={k.lower(): v for k, v in resp.getheaders()},
            redirect_chain=chain,
            resolved_ips=target.ips,
            net_mode=policy.mode,
            net_note=target.ip_note or policy.describe(),
            ip_check_relaxed=target.ip_relaxed,
        )

    raise TooManyRedirectsError("重定向处理异常终止。")
