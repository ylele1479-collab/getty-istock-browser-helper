"""Acquire previews without saving images. User reviews every result."""
import re
import time
from pathlib import Path
from dataclasses import dataclass, field
from contextlib import nullcontext
from copy import deepcopy
from urllib.parse import urlsplit
from .errors import GettyToolError, NoSourceFoundError, InvalidUrlError
from .netguard import fetch
from .urlparse_gt import identify, extract_candidates, build_detail_url, KIND_DIRECT_LINK
from .verify import verify_image
from .repair import repair_from_donor
from .output_guard import check_known_overlays
from .browser_sources import parse_browser_sources, public_url
from .source_identity import match_same_photo
from .source_fetch import ordered_source_reads
from .errors import looks_like_block_page

QUALITY_POLICY = {"auto_save": False, "preview_first": True, "watermark_check": "user_review",
                  "output_sizes": ["source"], "allow_upscale": False}

@dataclass
class JobResult:
    ok: bool = False
    payload: dict = field(default_factory=dict)
    image_bytes: bytes = b""
    original_bytes: bytes = b""
    comparison_bytes: bytes = b""
    filename: str = ""
    def to_dict(self):
        return {"ok": self.ok, **self.payload}

class AcquiredImages(list):
    """Keep the primary response separate from later comparison candidates."""
    def __init__(self):
        super().__init__()
        self.primary=None
        self.source_via={}
        self.candidate_checks=[]

def canonical_page(ref):
    if ref.provider == 'istock':
        return build_detail_url(ref.asset_id)
    if ref.kind != KIND_DIRECT_LINK:
        return ref.raw
    slug = Path(urlsplit(ref.raw).path).stem
    if re.fullmatch(r"[A-Za-z0-9-]+", slug):
        return f"https://www.gettyimages.com/detail/photo/{slug}-royalty-free-image/{ref.asset_id}"
    return build_detail_url(ref.asset_id)

def _span(metrics, name):
    return metrics.span(name) if metrics is not None else nullcontext()


def _verify_image(body, metrics=None):
    if metrics is not None:
        metrics.increment('verify_calls')
    with _span(metrics, 'verify'):
        return verify_image(body)


def _verified_payload(body, known, *, metrics=None):
    """Reuse an exact, still-owned response without sharing mutable metadata."""
    for known_body, info in known:
        if (body is known_body and info.is_image
                and info.declared_content_type == ''):
            if metrics is not None:
                metrics.increment('verify_reuses')
            return deepcopy(info.to_dict())
    return _verify_image(body, metrics).to_dict()


def verified_asset_image(response, asset_id, provider='getty', *, metrics=None):
    """Check final redirect identity before treating bytes as this asset."""
    final=identify(response.url)
    if (not asset_id or final.kind!=KIND_DIRECT_LINK
            or not final.asset_id or final.asset_id!=asset_id or final.provider!=provider):
        raise InvalidUrlError("图片跳转后的素材编号与请求不一致，未使用该图片。")
    return response.body,_verify_image(response.body,metrics),final.watermark_param,response.url

def acquire_images(url, timeout, extra_sources=None, browser_sources=None, discovery_mode='normal', *, check_cancelled=None, metrics=None):
    if discovery_mode not in ('normal','direct_only'):
        raise InvalidUrlError("取图模式不正确。")
    def check():
        if check_cancelled: check_cancelled()
    def get(address, **kwargs):
        check()
        with _span(metrics, 'fetch'):
            return fetch(address,timeout=timeout,**kwargs)
    parsed = urlsplit(url)
    if (parsed.scheme == "https" and parsed.hostname == "short.askingtips.com"
            and parsed.path.startswith("/uploads/") and not parsed.query
            and re.search(r"\.(jpg|jpeg|png|webp)$", parsed.path, re.I)):
        if extra_sources or browser_sources:
            raise InvalidUrlError("第三方返回图片请单独预览，不与 Getty 图源融合。")
        fr=get(url)
        images=AcquiredImages()
        images.primary=(fr.body,_verify_image(fr.body,metrics),"third_party",url)
        images.append(images.primary);images.source_via[url]='imported'
        return "imported",images,["第三方返回图片，请通过预览核对水印和画质。"]
    ref=identify(url); images=AcquiredImages(); notes=[]; candidates=[]
    if not ref.asset_id:
        raise InvalidUrlError("无法确认图片的素材编号，请复制包含 /id/素材编号/ 的 Getty 图片链接。")
    bundle=parse_browser_sources(browser_sources,ref.asset_id,expected_provider=ref.provider)
    supplemental=[]
    for extra in extra_sources or []:
        extra_provider=identify(extra).provider
        if ref.provider=='getty' and extra_provider!='getty':
            raise InvalidUrlError("Getty 素材的补充图片只接受 Getty 官方地址。")
        source=identify(public_url(extra,ref.asset_id,provider=extra_provider))
        supplemental.append(source)
    if ref.kind == KIND_DIRECT_LINK:
        fr=get(ref.raw)
        options={'metrics':metrics} if metrics is not None else {}
        images.primary=verified_asset_image(fr,ref.asset_id,ref.provider,**options)
        images.append(images.primary)
        images.source_via[images.primary[3]]='direct'
    seen={ref.raw} if images.primary else set()
    attempts={}
    def read_candidates(values):
        for clean in (False,True):
            group=[(identify(address),via) for address,via in values if address not in seen]
            group=[v for v in group if (v[0].watermark_param=='0')==clean]
            group.sort(key=lambda v:(-(v[0].declared_size or 0),v[0].path_ext not in ('jpg','jpeg')))
            selected=[]
            for source,via in group:
                key=(source.provider,clean)
                limit=(1 if clean else 2) if ref.provider=='istock' and source.provider=='istock' else (2 if clean else 4)
                if attempts.get(key,0)>=limit:continue
                if source.raw in seen:continue
                seen.add(source.raw);attempts[key]=attempts.get(key,0)+1
                selected.append((source,via))
            def read_candidate(value):
                source=value[0]
                options={'metrics':metrics} if metrics is not None else {}
                return verified_asset_image(get(source.raw),ref.asset_id,source.provider,**options)
            for (source,via),item,error in ordered_source_reads(
                    selected,read_candidate,check_cancelled=check_cancelled):
                if error is None:
                    if source.provider!=ref.provider:
                        reference=images.primary or next((v for v in images
                            if identify(v[3]).provider==ref.provider),None)
                        with _span(metrics, 'identity'):
                            identity=match_same_photo(reference[0],item[0]) if reference else {'verified':False}
                        if not identity['verified']:
                            images.candidate_checks.append({'url':source.raw,'error':'PHOTO_MISMATCH',
                                                            'identity':identity})
                            notes.append('另一网站的同编号图片未通过同照片核对，未用作高清图源。')
                            continue
                    images.append(item);images.source_via[item[3]]=via
                    images.candidate_checks.append({'url':source.raw,'width':item[1].width,'height':item[1].height})
                else:
                    images.candidate_checks.append({'url':source.raw,'error':error.code})
                    notes.append(f"候选图源不可用：{error.message}")
    def read_istock_page():
        try:
            lookup=(ref.raw if ref.kind!=KIND_DIRECT_LINK else
                    f'https://www.istockphoto.com/hk/search/2/image?phrase={ref.asset_id}')
            page=get(lookup,headers={"Accept":"text/html"})
            final=identify(page.url)
            if final.asset_id!=ref.asset_id or final.provider!='istock' or final.kind==KIND_DIRECT_LINK:
                raise InvalidUrlError("iStock 编号查询没有进入目标照片详情页，未采用列表里的其他照片。")
            own=[c.url for c in extract_candidates(page.body.decode('utf8','ignore'),provider='istock')
                 if identify(c.url).asset_id==ref.asset_id]
            read_candidates([(address,'istock_detail') for address in own])
            if not own:notes.append('iStock 详情页未提供可核验的图片地址。')
        except GettyToolError as exc:
            if exc.code=='JOB_CANCELLED':raise
            notes.append(f'iStock 详情页暂不可用：{exc.message}')
    if ref.provider=='istock' and ref.kind!=KIND_DIRECT_LINK and discovery_mode=='normal':
        read_istock_page()
    observed=[(s.raw,'direct') for s in supplemental]
    if bundle:observed += [(address,'browser') for address in bundle.candidates]
    read_candidates(observed)
    def sufficient():
        return any((max(v[1].width,v[1].height)>=2048 and
                    min(v[1].width,v[1].height)>=1080) if ref.provider=='istock'
                   else max(v[1].width,v[1].height)>=1000 for v in images)
    if discovery_mode=='normal' and not ((observed or (ref.provider=='istock'
                                                       and ref.kind!=KIND_DIRECT_LINK)) and sufficient()):
        try:
            page=get(canonical_page(ref),headers={"Accept":"text/html"})
            text=page.body.decode("utf8","ignore")
            page_provider=identify(page.url).provider if '/bot-wall' not in page.url else 'getty'
            candidates=[c for c in extract_candidates(text,provider=page_provider)
                        if identify(c.url).asset_id==ref.asset_id]
            if "/bot-wall" in page.url or (looks_like_block_page(text) and not candidates):
                notes.append("官网详情页当前要求访问验证，未绕过验证；只能使用已可获取的图片链接。")
            else:
                if identify(page.url).asset_id!=ref.asset_id:
                    raise InvalidUrlError("详情页跳转后的素材编号与请求不一致。")
                if not candidates: notes.append("详情页没有提供可提取的图片地址。")
                read_candidates([(c.url,'detail_page') for c in candidates])
        except GettyToolError as exc:
            if exc.code=='JOB_CANCELLED':raise
            notes.append(f"详情页暂时不可用：{exc.message}")
    if ref.provider=='istock' and ref.kind==KIND_DIRECT_LINK and discovery_mode=='normal' and not sufficient():
        read_istock_page()
    if not images:
        raise NoSourceFoundError("没有取得可预览的图片。"+"；".join(notes))
    return ref.asset_id or "asset",images,notes

def run_job(url, *, timeout=30, allow_repair=True, extra_sources=None, browser_sources=None, discovery_mode='normal', check_cancelled=None, metrics=None, **ignored):
    start=time.perf_counter(); result=JobResult(payload={"input_url":url,"auto_saved":False})
    try:
        options={'metrics':metrics} if metrics is not None else {}
        with _span(metrics, 'acquire'):
            asset,images,notes=acquire_images(url,timeout,extra_sources=extra_sources,browser_sources=browser_sources,
                discovery_mode=discovery_mode,check_cancelled=check_cancelled,**options)
        input_image=getattr(images,'primary',None) or next((v for v in images if v[3]==url),None)
        comparison_is_input=input_image is not None
        if input_image is None:
            clean=[v for v in images if v[2]=='0']
            input_image=min(clean or images,key=lambda v:v[1].width*v[1].height)
        images.sort(key=lambda v:v[1].width*v[1].height,reverse=True)
        body,vr,wm,chosen=images[0]; original=body; repair={"applied":False}
        donors=[v for v in images if v[2]=="0" and v[3]!=chosen]
        if check_cancelled:check_cancelled()
        if allow_repair and donors:
            # Size and w=0 are hints, not proof of a clean reference. If a
            # larger reference is unsafe, try the remaining observed versions
            # against the original source, never against a partly patched image.
            attempts=[]
            for donor in sorted(donors,key=lambda v:v[1].width*v[1].height,reverse=True):
                if check_cancelled:check_cancelled()
                with _span(metrics, 'repair'):
                    repaired,report=repair_from_donor(original,donor[0])
                attempts.append({'width':donor[1].width,'height':donor[1].height,
                                 'reason':report['reason_code']})
                if report['applied']:
                    body,repair=repaired,report
                    break
                if not repair.get('reason_code'):repair=report
            repair['reference_attempts']=attempts
        else:
            repair['reason_code']='disabled' if not allow_repair else 'no_donor' if not donors else 'not_attempted'
        larger=vr.width*vr.height>input_image[1].width*input_image[1].height
        upgrade={'status':'input_only','reason_code':'input_only'}
        if larger or repair['applied']:
            # A larger watermarked source is not a successful upgrade when
            # fusion fails. Never silently replace a clean input with that
            # source. A completed patch also needs a final residual check.
            with _span(metrics, 'output_guard'):
                upgrade=check_known_overlays(body,check_cancelled=check_cancelled)
            if upgrade['status']=='no_known_overlay_detected' and wm!='0' and not repair['applied']:
                upgrade={'status':'suspected','reason_code':'upgrade_unrepaired'}
            if upgrade['status']!='no_known_overlay_detected':
                reasons={'remaining_watermark':'高清候选图处理后仍检测到水印，已保留输入原图。',
                    'output_check_unavailable':'高清候选图的水印检查暂不可用，已保留输入原图。',
                    'upgrade_unrepaired':'高清候选图未能完成可靠的水印处理，已保留输入原图。'}
                fallback='kept_input' if comparison_is_input else 'kept_source'
                reason=reasons[upgrade['reason_code']]
                if not comparison_is_input:
                    reason=reason.replace('已保留输入原图。','未通过输出检查；保留未修补源图供检查，未宣称无水印。')
                upgrade.update(status=fallback,reason=reason)
                if repair['applied']:
                    repair={**repair,'applied':False,'attempt_applied':True,'output_discarded':True,
                        'attempt_reason_code':repair['reason_code'],'reason_code':upgrade['reason_code'],
                        'reason':upgrade['reason']}
                body=input_image[0] if comparison_is_input else original
                notes.append(upgrade['reason'])
            else:
                upgrade.update(status='preview_checked',reason='未检测到已知品牌文字或角落编号；仍请放大检查水印和接缝。')
        if repair["applied"]:
            status="修补预览 · 请检查效果"
            notes.append("局部使用同一素材较小版本融合，修补区细节会较软；请检查文字、底条和接缝。")
        elif wm not in ("0", ""):
            status="带水印源图 · 请检查"
            if not allow_repair:
                notes.append("本次关闭了水印区域修补，保留未修补源图。")
            elif repair.get('reason'):
                notes.append(repair['reason'])
            else:
                notes.append("未取得可用的同素材较小版本，保留源图预览，未标注为已去水印。")
        else:
            status="公开图片 · 请检查水印"
            notes.append("网址参数不能保证无水印，最终以你看到的画面为准。")
        with _span(metrics, 'output_verify'):
            known=[(image[0],image[1]) for image in images]
            known.append((input_image[0],input_image[1]))
            source_image=_verified_payload(original,known,metrics=metrics)
            output_image=_verified_payload(body,known,metrics=metrics)
        source_high=max(vr.width,vr.height)>=2048 and min(vr.width,vr.height)>=1080
        ow,oh=output_image['width'],output_image['height']
        high=max(ow,oh)>=2048 and min(ow,oh)>=1080
        long=max(ow,oh)
        level='high' if high else 'standard' if long>=1000 else 'low'
        if level=='low':
            status='仅取得小图 · 未取得高清'
            quality_note=f"当前输出为 {ow}×{oh} 的小图，尺寸偏小。保持实际像素，不用放大充当高清。"
        elif level=='standard':
            quality_note=f"实际输出 {ow}×{oh} 版本，清晰度是否满意由你查看预览决定。"
        else:
            quality_note=f"实际输出 {ow}×{oh} 高清预览；修补区域的细节会比其他位置软一些。" if repair['applied'] else f"实际输出 {ow}×{oh} 版本，请检查水印和细节。"
        if upgrade['status'] in ('kept_input','kept_source'):
            status=('保留原图' if comparison_is_input else '源图预览')+' · 高清水印检查未通过'
            quality_note=upgrade['reason']+f" 当前输出 {ow}×{oh}。"+('画质未提升。' if comparison_is_input else '输入为素材页，不能宣称相对输入图片的画质提升。')
        notes.append(quality_note)
        suffix="_REPAIRED" if repair["applied"] else ""
        ext={"JPEG":"jpg","PNG":"png","WEBP":"webp","TIFF":"tiff"}.get(output_image["format"],"img")
        result.filename=f"{asset}_{output_image['width']}x{output_image['height']}{suffix}.{ext}"
        result.image_bytes=body;result.original_bytes=original
        result.comparison_bytes=input_image[0]
        result.payload.update({"asset_id":asset,"filename":result.filename,"source_image":source_image,
           "output_image":output_image,"source_url":chosen,"source_high_resolution":source_high,
           "modified":repair["applied"],"repair":repair,"status_label":status,"notes":notes,
           "upscaled":False,"output_size":"source","comparison_image":input_image[1].to_dict(),
           "resolution_level":level,"quality_note":quality_note,"comparison_is_input":comparison_is_input,
           "upgrade_check":upgrade})
        result.payload['source_check']={'status':'larger_found' if larger else 'input_only' if comparison_is_input else 'reference_only',
            'via':getattr(images,'source_via',{}).get(chosen,'direct'),
            'reason':('已找到更大的同素材图源，但未用作解析后图片。' if upgrade['status']=='kept_input' else '仅供检查未修补源图，水印检查未通过。' if upgrade['status']=='kept_source' else '已取得实际像素较大的同素材图源。') if larger else '未取得比输入更大的图源。'}
        result.payload['candidate_checks']=getattr(images,'candidate_checks',[])
        result.payload['repair_check']={'status':'discarded' if upgrade['status'] in ('kept_input','kept_source') else 'preview' if repair['applied'] else 'disabled' if not allow_repair else 'unmodified',
            'reason':repair['reason_code']}
        result.ok=True
    except GettyToolError as exc:
        result.payload["error"]=exc.to_dict()
    except Exception as exc:
        result.payload["error"]={"code":"PREVIEW_FAILED","title":"未能生成预览","message":str(exc)}
    result.payload["elapsed_ms"]=round((time.perf_counter()-start)*1000)
    if metrics is not None:
        result.payload['metrics']=metrics.snapshot()
    return result

def save_qualified_image(data, directory, filename):
    directory=directory.expanduser().resolve();directory.mkdir(parents=True,exist_ok=True)
    base=Path(filename).name
    for n in range(10000):
        name=base if n==0 else f"{Path(base).stem}_{n}{Path(base).suffix}"
        target=directory/name
        try: stream=target.open("xb")
        except FileExistsError: continue
        try:
            with stream:
                if stream.write(data)!=len(data): raise OSError("图片写入不完整")
        except OSError:
            target.unlink(missing_ok=True);raise
        return target
    raise OSError("同名文件过多，请更换目录。")
