"""Validate public browser observations without trusting size or watermark claims."""
from dataclasses import dataclass
from urllib.parse import urlsplit
from .errors import InvalidUrlError
from .urlparse_gt import identify, KIND_DIRECT_LINK, KIND_DETAIL_PAGE

@dataclass(frozen=True)
class BrowserSourceBundle:
    asset_id: str
    page_url: str
    candidates: tuple[str, ...]

def public_url(url, asset_id, *, page=False, provider='getty'):
    if not isinstance(url,str) or len(url)>8192:
        raise InvalidUrlError("图源地址格式不正确。")
    try:
        u=urlsplit(url)
        ref=identify(url)
        if page:
            allowed=(('www.gettyimages.com','www.gettyimages.hk','www.gettyimages.co.jp') if provider=='getty'
                     else ('www.istockphoto.com',))
        else:
            allowed=(('media.gettyimages.com',) if provider=='getty' else ('media.istockphoto.com',))
        if (u.scheme!='https' or u.hostname not in allowed or u.username or u.password
                or u.port not in (None,443) or ref.asset_id!=asset_id
                or ref.provider!=provider
                or ref.kind!=(KIND_DETAIL_PAGE if page else KIND_DIRECT_LINK)):
            raise ValueError()
    except (ValueError,TypeError):
        raise InvalidUrlError("浏览器图源必须是同素材的官方公开地址。") from None
    return url

def parse_browser_sources(data, expected_asset_id, expected_provider='getty'):
    if data is None:return None
    if not isinstance(data,dict) or set(data)!={'asset_id','page_url','candidates'}:
        raise InvalidUrlError("浏览器图源包只接受素材编号、页面地址和候选列表。")
    if data['asset_id']!=expected_asset_id:
        raise InvalidUrlError("浏览器图源的素材编号与输入不一致。")
    page_provider=identify(data['page_url']).provider
    if expected_provider=='getty' and page_provider!='getty':
        raise InvalidUrlError("Getty 输入只接受 Getty 官方素材页。")
    page=public_url(data['page_url'],expected_asset_id,page=True,provider=page_provider)
    values=data['candidates']
    if not isinstance(values,list) or len(values)>20:
        raise InvalidUrlError("浏览器图源最多20条。")
    candidates=tuple(dict.fromkeys(public_url(v,expected_asset_id,provider=page_provider) for v in values))
    return BrowserSourceBundle(expected_asset_id,page,candidates)
