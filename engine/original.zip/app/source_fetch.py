"""Bounded parallel reads, consumed in the caller's preferred URL order."""
from collections import deque
from concurrent.futures import ThreadPoolExecutor, wait

from .errors import GettyToolError


def ordered_source_reads(values, read, *, check_cancelled=None):
    """Overlap at most three reads without racing source preference or state.

    Workers only produce values. The caller consumes and records each outcome
    in its original order. Cancellation stops queued work; in-flight network
    reads retain their existing timeouts and cannot publish a result.
    """
    values = iter(values)
    pending = deque()
    executor = ThreadPoolExecutor(max_workers=3, thread_name_prefix='getty-source')

    def check():
        if check_cancelled:
            check_cancelled()

    def guarded_read(value):
        check()
        result = read(value)
        check()
        return result

    def schedule_next():
        check()
        try:
            value = next(values)
        except StopIteration:
            return
        pending.append((value, executor.submit(guarded_read, value)))

    try:
        for _ in range(3):
            schedule_next()
        while pending:
            value, future = pending.popleft()
            while True:
                check()
                done, _ = wait((future,), timeout=.05)
                if not done:
                    continue
                try:
                    item = future.result()
                    error = None
                    break
                except GettyToolError as exc:
                    if exc.code == 'JOB_CANCELLED':
                        raise
                    item, error = None, exc
                    break
            check()
            yield value, item, error
            schedule_next()
    finally:
        for _, future in pending:
            future.cancel()
        executor.shutdown(wait=False, cancel_futures=True)

