"""Conservative fallback for a confirmed Getty strip on an aligned large image.

Only the overlay band and corner label borrow pixels from a clean, smaller
variant of the *same* photograph. The rest remains the acquired HD source.
"""
import io
import math
from functools import lru_cache
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

from .ocr_guard import text_lines
from .output_guard import check_known_overlays, is_stock_credit_line


def _extend_band_for_credit(source, y0, y1, hi, dw, dh):
    """Include a source-only credit line touching the verified Getty band."""
    h,w=source.shape[:2]
    top=round(y0*h/dh)
    bottom=round(y1*h/dh)
    search_end=min(round(hi*h/dh),bottom+max(48,round(h*.06)))
    if search_end<=top:
        return y1
    lines=text_lines(source[top:search_end,int(w*.35):])
    if lines is None:
        return y1  # The output check will decline an unchecked result.
    for _,line_top,_,line_bottom,word,score in lines:
        if (is_stock_credit_line(word,score)
                and top+line_top<=bottom+max(12,round(h*.025))
                and top+line_bottom>bottom):
            y1=max(y1,min(hi,math.ceil((top+line_bottom+max(6,round(h*.005)))*dh/h)))
    return y1


@lru_cache(maxsize=1)
def _brand_edge_templates():
    """Small glyph shapes supplement OCR for very faint reference lettering."""
    font_path=Path('C:/Windows/Fonts/arial.ttf')
    if not font_path.is_file():
        return None
    templates=[]
    for size in range(10,23,2):
        font=ImageFont.truetype(str(font_path),size)
        box=font.getbbox('gettyimages')
        tile=Image.new('L',(box[2]-box[0]+4,box[3]-box[1]+4),0)
        ImageDraw.Draw(tile).text((2-box[0],2-box[1]),'gettyimages',font=font,fill=255)
        templates.append(cv2.Laplacian(np.asarray(tile).astype(np.float32),cv2.CV_32F,ksize=3))
    return templates


def _faint_brand_in_reference(donor, box):
    templates=_brand_edge_templates()
    if not templates:
        return True  # Do not certify an unchecked reference.
    x0,y0,x1,y1=box
    gray=cv2.cvtColor(donor,cv2.COLOR_RGB2GRAY)
    edges=cv2.Laplacian(gray.astype(np.float32),cv2.CV_32F,ksize=3)[y0:y1,x0:x1]
    for template in templates:
        if edges.shape[0]<template.shape[0] or edges.shape[1]<template.shape[1]:
            continue
        if float(cv2.matchTemplate(edges,template,cv2.TM_CCOEFF_NORMED).max())>=.30:
            return True
    return False


def repair_verified_band(source, donor, donor_bytes, *, reference_text_guard):
    """Return (JPEG, report), or None when any provenance check is uncertain."""
    h,w=source.shape[:2]
    dh,dw=donor.shape[:2]
    if min(w,h)<1000 or max(dw,dh)>max(w,h)*.7:
        return None
    if abs((dw/dh)/(w/h)-1)>.015:
        return None

    low=cv2.resize(source,(dw,dh),interpolation=cv2.INTER_AREA)
    a=cv2.GaussianBlur(low.astype(np.float32),(0,0),.65)
    b=cv2.GaussianBlur(donor.astype(np.float32),(0,0),.65)
    delta=np.max(np.abs(a-b),axis=2)
    outside=np.ones((dh,dw),bool)
    outside[int(dh*.50):int(dh*.84),int(dw*.35):]=False
    outside[int(dh*.88):,:int(dw*.42)]=False

    # Color grading may differ, but the same photo retains almost identical
    # object boundaries. This rejects a different pose or a look-alike image.
    gray_a=cv2.cvtColor(low,cv2.COLOR_RGB2GRAY).astype(np.float32)
    gray_b=cv2.cvtColor(donor,cv2.COLOR_RGB2GRAY).astype(np.float32)
    edge_a=cv2.magnitude(cv2.Sobel(gray_a,cv2.CV_32F,1,0),cv2.Sobel(gray_a,cv2.CV_32F,0,1))
    edge_b=cv2.magnitude(cv2.Sobel(gray_b,cv2.CV_32F,1,0),cv2.Sobel(gray_b,cv2.CV_32F,0,1))
    correlation=float(np.corrcoef(edge_a[outside].ravel(),edge_b[outside].ravel())[0,1])
    if not np.isfinite(correlation) or correlation<.95:
        return None

    baseline=float(np.median(delta[outside]))
    rows=np.median(delta[:,int(dw*.50):],axis=1)
    lo,hi=int(dh*.50),int(dh*.84)
    strong=np.flatnonzero(rows[lo:hi]>max(16,baseline*2.1))+lo
    if not len(strong):
        return None
    groups=np.split(strong,np.where(np.diff(strong)>2)[0]+1)
    groups=[group for group in groups if len(group)>=max(4,dh*.018)]
    if not groups:
        return None
    core=max(groups,key=len)
    y0=max(lo,int(core[0])-5)
    y1=min(hi,int(core[-1])+6)
    if not (.025*dh<=y1-y0<=.15*dh):
        return None

    # The conspicuous row difference alone could be an image alteration.
    # Require Getty branding in this precise band and a separately checked
    # reference without detected branding or corner labels.
    brand_crop=source[round(y0*h/dh):round(y1*h/dh),int(w*.35):]
    lines=text_lines(brand_crop)
    if lines is None or not any(score>=.5 and 'getty' in ''.join(c for c in word.lower() if c.isalnum())
                                for *_,word,score in lines):
        return None
    x0=int(dw*.35)
    if _faint_brand_in_reference(donor,(x0,y0,dw,y1)):
        return None
    if check_known_overlays(donor_bytes)['status']!='no_known_overlay_detected':
        return None

    y1=_extend_band_for_credit(source,y0,y1,hi,dw,dh)

    if reference_text_guard(a,b,(max(0,x0-8),max(0,y0-8),dw,min(dh,y1+8)),
                            max(9,baseline*3.5),donor):
        return None

    mask=np.zeros((dh,dw),np.uint8)
    mask[y0:y1,x0:]=255
    corner_y=int(dh*.93)
    corner_x=int(dw*.30)
    mask[corner_y:,:corner_x]=255
    if float(np.mean(mask>0))>.14:
        return None

    # Fit the donor's color to the surrounding source, then interpolate only
    # its low-frequency residual across the masked area. Using the watermarked
    # source to compute residual *inside* the mask would restore a ghost strip.
    fit_mask=cv2.dilate(mask,np.ones((15,15),np.uint8))==0
    samples=donor[fit_mask][::3].astype(np.float32)
    targets=low[fit_mask][::3].astype(np.float32)
    if len(samples)<100:
        return None
    design=np.c_[samples,np.ones(len(samples),np.float32)]
    matrix=np.linalg.lstsq(design,targets,rcond=None)[0]
    high_donor=cv2.resize(donor,(w,h),interpolation=cv2.INTER_LANCZOS4).astype(np.float32)
    mapped=np.clip(np.c_[high_donor.reshape(-1,3),np.ones(h*w,np.float32)]@matrix,0,255).reshape(h,w,3)
    mapped_low=cv2.resize(mapped,(dw,dh),interpolation=cv2.INTER_AREA)
    residual=low.astype(np.float32)-mapped_low
    residual=np.stack([cv2.inpaint(residual[:,:,channel].astype(np.float32),mask,7,cv2.INPAINT_TELEA)
                       for channel in range(3)],axis=2)
    residual=cv2.resize(residual,(w,h),interpolation=cv2.INTER_CUBIC)
    residual=cv2.GaussianBlur(residual,(0,0),max(15,w/40))
    corrected=np.clip(mapped+residual,0,255)

    hard=cv2.resize(mask,(w,h),interpolation=cv2.INTER_NEAREST)
    expanded=cv2.dilate(hard,np.ones((15,15),np.uint8))
    soft=cv2.GaussianBlur(expanded,(0,0),max(3,w/290)).astype(np.float32)/255
    soft=np.maximum(soft,hard/255)[...,None]
    output=np.clip(corrected*soft+source.astype(np.float32)*(1-soft),0,255).astype(np.uint8)
    buffer=io.BytesIO()
    Image.fromarray(output).save(buffer,'JPEG',quality=95,subsampling=0)
    regions=[{'x':round(x0*w/dw),'y':round(y0*h/dh),'width':w-round(x0*w/dw),
              'height':round((y1-y0)*h/dh)},
             {'x':0,'y':round(corner_y*h/dh),'width':round(corner_x*w/dw),
              'height':h-round(corner_y*h/dh)}]
    report={'applied':True,'reason_code':'applied','donor_dimensions':f'{dw}×{dh}',
            'regions':regions,'transition_regions':[],
            'coverage':float(np.mean(hard>0)),
            'transition_coverage':float(np.mean((soft[...,0]>0)&(hard==0))),
            'background_difference':round(baseline,2),'edge_correlation':round(correlation,4),
            'region_selection':'verified_brand_band_and_corner',
            'overlay_evidence':'getty_text_in_source_band_absent_from_donor',
            'method':'同照片小图仅补品牌横条及角落；其他区域保留真实高清像素，修补区细节较软'}
    return buffer.getvalue(),report
