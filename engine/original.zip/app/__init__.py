# -*- coding: utf-8 -*-
"""Getty 素材获取与核验工具。"""

__version__ = "1.0.0"
