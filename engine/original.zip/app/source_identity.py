"""Conservative visual check before accepting a cross-site photo source."""
import io
import cv2
import numpy as np
from PIL import Image, ImageOps


def match_same_photo(reference: bytes, candidate: bytes) -> dict:
    try:
        with Image.open(io.BytesIO(reference)) as im:
            small = np.asarray(ImageOps.exif_transpose(im).convert('RGB'))
        with Image.open(io.BytesIO(candidate)) as im:
            large = np.asarray(ImageOps.exif_transpose(im).convert('RGB'))
    except Exception:
        return {'verified': False, 'reason_code': 'decode_failed'}
    sh, sw = small.shape[:2]
    lh, lw = large.shape[:2]
    if min(sh, sw, lh, lw) < 80 or abs((sw / sh) / (lw / lh) - 1) > .015:
        return {'verified': False, 'reason_code': 'different_crop'}
    width = min(sw, 612)
    height = round(sh * width / sw)
    a = cv2.resize(small, (width, height), interpolation=cv2.INTER_AREA)
    b = cv2.resize(large, (width, height), interpolation=cv2.INTER_AREA)
    a = cv2.GaussianBlur(a.astype(np.float32), (0, 0), .65)
    b = cv2.GaussianBlur(b.astype(np.float32), (0, 0), .65)
    # Public variants may differ in Getty's central strip and corner credit.
    mask = np.ones((height, width), bool)
    mask[int(height*.48):int(height*.85), int(width*.30):] = False
    mask[int(height*.88):, :int(width*.44)] = False
    delta = np.max(np.abs(a-b), axis=2)[mask]
    median = float(np.median(delta))
    p85 = float(np.percentile(delta, 85))
    texture = float(np.std(cv2.cvtColor(a.astype('uint8'), cv2.COLOR_RGB2GRAY)[mask]))
    verified = texture >= 8 and median <= 12 and p85 <= 30
    return {'verified': verified,
            'reason_code': 'same_photo' if verified else 'weak_or_different_photo',
            'metrics': {'median_difference': round(median, 2),
                        'p85_difference': round(p85, 2), 'texture': round(texture, 2)}}
