"""Local text evidence for ambiguous contours; never fetch models at runtime."""
from pathlib import Path
import os
import sys
import threading
import cv2
import numpy as np

_workers=min(2,os.cpu_count() or 1)
_threads=max(1,min(3,(os.cpu_count() or 1)//_workers))
_engines=[None]*_workers
_available=list(range(_workers))
_condition=threading.Condition()

def _create_engine():
    vendor=Path(__file__).resolve().parents[1]/'vendor'/'ocr'
    if vendor.is_dir() and str(vendor) not in sys.path:sys.path.insert(0,str(vendor))
    import rapidocr
    from rapidocr import RapidOCR
    models=Path(rapidocr.__file__).parent/'models'
    det=models/'PP-OCRv6_det_small.onnx';rec=models/'PP-OCRv6_rec_small.onnx'
    if not det.is_file() or not rec.is_file():return None
    return RapidOCR(params={'Global.use_cls':False,'Global.log_level':'error',
        'Det.model_path':str(det),'Rec.model_path':str(rec),
        'EngineConfig.onnxruntime.intra_op_num_threads':_threads,
        'EngineConfig.onnxruntime.inter_op_num_threads':1,
        'EngineConfig.onnxruntime.enable_cpu_mem_arena':True})

def text_lines(rgb,enhance=False,*,check_cancelled=None):
    """Return local boxes/recognized text, or None if checking is unavailable.

    Absence of a recognized word does not certify a clean image. The caller
    must also require alignment and source-only overlay evidence.
    """
    # RapidOCR mutates its detector parameters during inference. Each slot is
    # exclusively leased, with at most two model sets across all requests.
    with _condition:
        if check_cancelled:check_cancelled()
        while not _available:
            _condition.wait(.1)
            if check_cancelled:check_cancelled()
        slot=_available.pop(0)
    try:
        if _engines[slot] is None:_engines[slot]=_create_engine()
        if _engines[slot] is None:return None
        image=np.clip(rgb,0,255).astype('uint8')
        if enhance:
            gray=image.mean(axis=2).astype('float32')
            residual=gray-cv2.GaussianBlur(gray,(0,0),4)
            image=cv2.cvtColor(np.clip(128+residual*5,0,255).astype('uint8'),cv2.COLOR_GRAY2RGB)
        image=cv2.resize(image,None,fx=3,fy=3,interpolation=cv2.INTER_CUBIC)
        output=_engines[slot](image[...,::-1].copy(),use_cls=False,box_thresh=.3)
        if output.boxes is None:return []
        return [(float(box[:,0].min()/3),float(box[:,1].min()/3),
                 float(box[:,0].max()/3),float(box[:,1].max()/3),str(word),float(score))
                for box,word,score in zip(output.boxes,output.txts,output.scores)]
    except Exception:
        # Missing dependency/model or inference failure is not evidence
        # that the donor is clean. The caller retains the original guard.
        return None
    finally:
        with _condition:
            _available.append(slot)
            _condition.notify()

