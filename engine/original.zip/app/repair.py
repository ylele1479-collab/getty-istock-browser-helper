"""Full-overlay fusion using the same asset's lower-resolution variant."""
import io
import cv2
import numpy as np
from PIL import Image, ImageOps
from .ocr_guard import text_lines
from .wide_overlay import repair_verified_band

def source_overlay_evidence(a,b,box,threshold):
    """Only trust source overlay boundaries that are absent in the donor.

    Absolute differences alone do not tell which image carries an overlay.
    Dark/light differences reverse with the underlying photo, so direction is
    not proof. Ambiguous textured boundaries are deliberately declined.
    """
    x,y,rw,rh=map(int,box[:4]);x1=x+rw;y1=y+rh
    changed=np.max(np.abs(a[y:y1,x:x1]-b[y:y1,x:x1]),axis=2)>threshold
    if not np.any(changed):
        return False
    def boundary(image):
        gray=np.mean(image,axis=2);scores=[]
        for edge in (y,y1):
            edge_scores=[]
            for row in range(max(0,edge-3),min(len(gray)-1,edge+4)):
                edge_scores.append(float(np.median(np.abs(gray[row+1,x:x1]-gray[row,x:x1]))))
            scores.append(edge_scores)
        return scores
    source_edges=boundary(a);donor_edges=boundary(b)
    source_edge=max((v for edge in source_edges for v in edge),default=0)
    donor_edge=max((v for edge in donor_edges for v in edge),default=0)
    if source_edge>=5 and donor_edge<=4 and source_edge>=donor_edge*2+3:
        return True
    # A faint transparent strip can have a weak edge. Require evidence at
    # BOTH horizontal boundaries and a dense changed area, rather than simply
    # lowering the single-edge threshold (which would accept ordinary texture).
    return (np.mean(changed)>=.30 and donor_edge<=2 and
            all(any(s>=2.5 and s>=d*2+1 for s,d in zip(source_rows,donor_rows))
                for source_rows,donor_rows in zip(source_edges,donor_edges)))

def aligned_strip_components(stats,dw,dh):
    """Join only neighboring, vertically aligned fragments of one strip."""
    fragments=[s for s in stats if s[2]>=dw*.06 and max(4,dh*.02)<=s[3]<=max(dh*.18,dw*.08)
               and s[4]/max(s[2]*s[3],1)>=.30]
    groups=[]
    for s in sorted(fragments,key=lambda s:s[0]):
        x,y,rw,rh,area=map(int,s)
        for group in groups:
            gx,gy,gw,gh,ga=group
            if (0<=x-(gx+gw)<=max(9,dw*.04) and abs(y-gy)<=3
                    and abs(y+rh-(gy+gh))<=3):
                bottom=max(gy+gh,y+rh);group[:]=[gx,min(gy,y),x+rw-gx,bottom-min(gy,y),ga+area]
                break
        else:groups.append([x,y,rw,rh,area])
    return groups

def _reference_has_edge_candidates(a,b,box,threshold):
    """Decline compact text-like strokes appearing only in the copied reference.

    This is conservative evidence, not a claim that an arbitrary reference is
    watermark-free. Shared photographic edges do not count; ambiguous new
    high-contrast strokes in the patch or feather margin must not be copied.
    """
    x0,y0,x1,y1=box
    source=np.mean(a[y0:y1,x0:x1],axis=2)
    donor=np.mean(b[y0:y1,x0:x1],axis=2)
    if min(source.shape,default=0)<2:return False
    def edge(gray):
        dx=np.pad(np.abs(np.diff(gray,axis=1)),((0,0),(0,1)))
        dy=np.pad(np.abs(np.diff(gray,axis=0)),((0,1),(0,0)))
        return np.maximum(dx,dy)
    sa=edge(source);sb=edge(donor)
    changed=np.max(np.abs(a[y0:y1,x0:x1]-b[y0:y1,x0:x1]),axis=2)>threshold
    strokes=((sb>12)&(sb>sa*3+8)&changed).astype('uint8')*255
    strokes=cv2.morphologyEx(strokes,cv2.MORPH_CLOSE,np.ones((3,7),np.uint8))
    _,_,stats,_=cv2.connectedComponentsWithStats(strokes)
    dh,dw=a.shape[:2]
    if any(area>=20 and rw>=max(12,dw*.025) and rw/max(rh,1)>=1.5
           and rh<=max(12,dh*.05) for _,_,rw,rh,area in stats[1:]):
        return True
    # Faint lettering can connect to a tall photographic edge. Detect rows of
    # new horizontal stroke boundaries separately: vertical walls/hair must
    # not turn a compact text row into one tall component and hide it. Require
    # a much wider line at this weaker threshold; isolated texture is declined
    # only by the stronger check above, not by one faint pixel.
    sy=np.pad(np.abs(np.diff(source,axis=0)),((0,1),(0,0)))
    dy=np.pad(np.abs(np.diff(donor,axis=0)),((0,1),(0,0)))
    rows=((dy>4)&(dy>sy*2+2)).astype('uint8')*255
    rows=cv2.morphologyEx(rows,cv2.MORPH_CLOSE,np.ones((3,7),np.uint8))
    line_height=min(len(rows),max(12,round(dh*.05)))
    for start in range(0,len(rows)-line_height+1,3):
        _,_,line_stats,_=cv2.connectedComponentsWithStats(rows[start:start+line_height])
        if any(area>=20 and rw>=max(30,dw*.08) and rh>=5 and rw/rh>=1.5
               for _,_,rw,rh,area in line_stats[1:]):
            return True
    return False

def _compact_glyph_group(source,donor,dw,dh):
    """Group whole short strokes before joining a word, not cropped contours."""
    def edge(gray):
        return np.maximum(np.pad(np.abs(np.diff(gray,axis=1)),((0,0),(0,1))),
                          np.pad(np.abs(np.diff(gray,axis=0)),((0,1),(0,0))))
    sa=edge(source);sb=edge(donor)
    raw_strokes=(sb>4)&(sb>sa*2+2)
    strokes=raw_strokes.astype('uint8')*255
    strokes=cv2.morphologyEx(strokes,cv2.MORPH_CLOSE,np.ones((2,2),np.uint8))
    _,_,stats,_=cv2.connectedComponentsWithStats(strokes)
    glyphs=[s for s in stats[1:] if s[4]>=3 and 2<=s[2]<=max(15,dw*.04)
            and 3<=s[3]<=max(12,dh*.04) and s[2]/s[3]<=3]
    for _,y,_,rh,_ in glyphs:
        line=[s for s in glyphs if abs(int(s[1]+s[3])-int(y+rh))<=3
              and abs(int(s[3])-int(rh))<=max(3,rh*.5)]
        group=[]
        for s in sorted(line,key=lambda s:s[0]):
            if group and s[0]-(group[-1][0]+group[-1][2])>max(6,rh):group=[]
            group.append(s)
            if len(group)>=4 and s[0]+s[2]-group[0][0]>=max(25,dw*.06):
                # The source strip dims existing beard/cloth contours. Those
                # contours still have matching weaker edges nearby; genuinely
                # added strokes in the donor lack that source correspondence.
                candidate=np.zeros_like(raw_strokes)
                for gx,gy,gw,gh,_ in group:candidate[gy:gy+gh,gx:gx+gw]=True
                candidate&=raw_strokes
                existing=cv2.dilate(sa,np.ones((3,3),np.uint8))>=sb*.3
                if np.any(candidate) and np.mean(existing[candidate])<.98:return True
    return False

class ReferenceCheckUnavailable(Exception):
    pass

def reference_has_new_text_edges(a,b,box,threshold,raw_reference=None):
    """Require word evidence rather than treating long clothing edges as text."""
    x0,y0,x1,y1=box;dh,dw=b.shape[:2]
    source=a[y0:y1,x0:x1].mean(axis=2);donor=b[y0:y1,x0:x1].mean(axis=2)
    if _compact_glyph_group(source,donor,dw,dh):return True
    # A tight strip crop can make a weak word merge with the crop boundary.
    # Supply surrounding photographic context, but only consider words that
    # intersect the area which could actually be copied.
    padding=max(20,(y1-y0)//2)
    left=max(0,x0-padding);top=max(0,y0-padding)
    right=min(dw,x1+padding);bottom=min(dh,y1+padding)
    reference=(b if raw_reference is None else raw_reference)[top:bottom,left:right]
    for enhance in (False,True):
        lines=text_lines(reference,enhance=enhance)
        if lines is None:raise ReferenceCheckUnavailable()
        for x,y,r,end,word,score in lines:
            width=r-x;height=end-y
            letters=''.join(c for c in word if c.isalnum())
            intersects=(r+left>x0 and x+left<x1 and end+top>y0 and y+top<y1)
            # Recognition is stronger evidence than an edge-component shape:
            # a text box may include nearby cloth and become too tall. Keep
            # geometric constraints only for a short, partial recognition.
            if intersects and score>=.5 and (len(letters)>=4 or
                    (len(letters)>=2 and width>=15 and 3<=height<=max(20,dh*.10) and width/height>=1.5)):return True
    return False

def _corner_number_region(source,donor,y0,x1,threshold,native_source=None):
    """Locate a source-only numeric corner label when hair touches its mask."""
    sh,sw=source.shape[:2]
    # Recognize at native resolution: a readable small source label can become
    # unrecognizable when shrunk to the reference's size. Map its box back to
    # the aligned comparison before measuring differences or copying pixels.
    text_source=source if native_source is None else native_source
    th,tw=text_source.shape[:2]
    text_top=max(round(y0*th/sh),int(th*.93))
    text_right=min(round(x1*tw/sw),round(tw*.30))
    source_lines=text_lines(text_source[text_top:,:text_right])
    donor_lines=text_lines(donor[y0:,:x1])
    if source_lines is None or donor_lines is None:raise ReferenceCheckUnavailable()
    if any(len(''.join(c for c in word if c.isdigit()))>=6 for *_,word,score in donor_lines):return None
    for x,y,right,bottom,word,score in source_lines:
        x=x*sw/tw;right=right*sw/tw
        y=(y+text_top)*sh/th-y0;bottom=(bottom+text_top)*sh/th-y0
        number=''.join(c for c in word if c.isalnum())
        if not number.isdigit() or len(number)<6 or score<.7:continue
        # Match the native crop's integer boundary when mapping back. Using
        # 93% again in the donor frame can reject a word by a fractional pixel.
        corner_top=int(th*.93)*sh/th
        if x>sw*.04 or y+y0<corner_top or right>sw*.30 or bottom-y>sh*.075:continue
        left=0;top=max(y0,int(y+y0)-4);right=min(x1,int(np.ceil(right))+4)
        bottom=min(sh,int(np.ceil(bottom+y0))+4)
        changed=np.max(np.abs(source[top:bottom,left:right].astype(float)-donor[top:bottom,left:right]),axis=2)>threshold
        if np.mean(changed)>=.30:return [left,top,right-left,bottom-top,int(np.count_nonzero(changed))]
    return None

def _repair_from_donor_trusted(source, donor):
    src=np.array(ImageOps.exif_transpose(Image.open(io.BytesIO(source))).convert('RGB'))
    small=np.array(ImageOps.exif_transpose(Image.open(io.BytesIO(donor))).convert('RGB'))
    h,w=src.shape[:2];dh,dw=small.shape[:2]
    report={'applied':False,'donor_dimensions':f'{dw}×{dh}','reason_code':'no_trusted_region',
            'regions':[],'transition_regions':[],'coverage':0,'transition_coverage':0}
    if abs((dw/dh)/(w/h)-1)>.015:
        report['reason_code']='unsafe_alignment'
        report['reason']='较小版本裁切比例不同，未自动融合。';return source,report
    low=cv2.resize(src,(dw,dh),interpolation=cv2.INTER_AREA)
    a=cv2.GaussianBlur(low.astype(np.float32),(0,0),.65)
    b=cv2.GaussianBlur(small.astype(np.float32),(0,0),.65)
    delta=np.max(np.abs(a-b),axis=2)
    outside=np.ones((dh,dw),bool)
    outside[int(dh*.50):int(dh*.84),int(dw*.35):]=False
    outside[int(dh*.88):,:int(dw*.42)]=False
    baseline=float(np.median(delta[outside]));report['background_difference']=round(baseline,2)
    if baseline>12 or np.percentile(delta[outside],85)>30:
        report['reason_code']='unsafe_alignment'
        report['reason']='较小版本与源图对齐或颜色不一致，未自动融合。';return source,report
    mask=np.zeros((dh,dw),np.uint8);regions=[]
    for x0,y0,x1,y1 in ((int(dw*.35),int(dh*.50),dw,int(dh*.84)),(0,int(dh*.88),int(dw*.42),dh)):
        active=(delta[y0:y1,x0:x1]>max(9,baseline*3.5)).astype(np.uint8)*255
        active=cv2.morphologyEx(active,cv2.MORPH_CLOSE,np.ones((5,9),np.uint8))
        if x0:
            # Isolate rows supporting the right-reaching strip before components.
            # Texture touching below the strip must not enlarge its repair box.
            supported=np.any(active[:,max(0,int(dw*.95)-x0):]>0,axis=1)&(np.count_nonzero(active,axis=1)>=max(8,dw*.18*.30))
            supported=cv2.morphologyEx(supported.astype('uint8')[:,None],cv2.MORPH_CLOSE,np.ones((5,1),np.uint8))[:,0]>0
            active[~supported]=0
        else:
            # Small text at the corner can touch a thin difference caused by
            # resize filters above it. Keep rows supported by the text's width
            # so that this texture does not turn a short label into a tall box.
            supported=np.count_nonzero(active[:,:int(dw*.30)],axis=1)>=max(8,dw*.04)
            supported=cv2.morphologyEx(supported.astype('uint8')[:,None],cv2.MORPH_CLOSE,np.ones((3,1),np.uint8))[:,0]>0
            active[~supported]=0
        _,_,stats,_=cv2.connectedComponentsWithStats(active)
        if x0:
            # A Getty strip is wide and nearly reaches the right edge. Its
            # faint tail may blend into the background and disconnect. Do not union
            # unrelated facial/cloth differences into one large repair box.
            good=[s for s in aligned_strip_components(stats[1:],dw,dh) if s[2]>=dw*.18 and s[2]/max(s[3],1)>=2.5
                  # Thin lines can come from resize filters on clean texture.
                  and max(4,dh*.02)<=s[3]<=max(dh*.18,dw*.08) and s[0]+x0+s[2]>=dw*.95
                  and s[4]/max(s[2]*s[3],1)>=.30]
        else:
            good=[s for s in stats[1:] if s[4]>=20 and s[2]>=8
                  and s[0]<=max(4,dw*.02) and s[1]+y0>=dh*.93
                  and s[2]<=dw*.30 and s[3]<=dh*.075]
        # Do not let a watermark in a w=0 donor become a replacement region.
        # Every plausible component must support source-only overlay evidence.
        threshold=max(9,baseline*3.5)
        ambiguous=any(not source_overlay_evidence(a,b,(s[0]+x0,s[1]+y0,*s[2:]),threshold) for s in good)
        if not good or ambiguous:
            try:
                number=_corner_number_region(low,small,y0,x1,threshold,native_source=src) if not x0 else None
            except ReferenceCheckUnavailable:
                report['reason_code']='reference_check_unavailable'
                report['reason']='本地角落文字检查暂不可用，已保留源图；未自动融合。'
                return source,report
            if number is None:
                if not good:continue
                report['reason']='无法确认覆盖层只存在于源图，参考图也可能带水印；未自动融合。'
                return source,report
            selected=[number[0],number[1]-y0,*number[2:]]
        else:selected=max(good,key=lambda s:s[4])
        gx0=max(0,selected[0]+x0-4);gy0=max(0,selected[1]+y0-4)
        gx1=dw if x0 else min(dw,selected[0]+selected[2]+x0+4)
        gy1=min(dh,selected[1]+selected[3]+y0+4)
        # Include the complete feather margin, not only the core rectangle.
        margin=int(np.ceil((7+4*max(3,w/290))*dw/w))+1
        try:
            extra_text=reference_has_new_text_edges(a,b,(max(0,gx0-margin),max(0,gy0-margin),
                min(dw,gx1+margin),min(dh,gy1+margin)),threshold,raw_reference=small)
        except ReferenceCheckUnavailable:
            report['reason_code']='reference_check_unavailable'
            report['reason']='本地参考图文字检查暂不可用，已保留源图；未自动融合。'
            return source,report
        if extra_text:
            report['reason_code']='reference_overlay_suspected'
            report['reason']='参考图的修补区域可能含有额外文字或水印，未自动融合。'
            return source,report
        mask[gy0:gy1,gx0:gx1]=255
        regions.append({'x':round(gx0*w/dw),'y':round(gy0*h/dh),
                        'width':round((gx1-gx0)*w/dw),'height':round((gy1-gy0)*h/dh),
                        'w':round((gx1-gx0)*w/dw),'h':round((gy1-gy0)*h/dh)})
    coverage=float(np.mean(mask>0))
    if not regions or coverage>.16:
        report['coverage']=round(coverage,6)
        report['reason_code']='coverage_limit' if coverage>.16 else 'no_trusted_region'
        report['reason']='没有可信的局部覆盖差异，未自动融合。';return source,report
    high_donor=cv2.resize(small,(w,h),interpolation=cv2.INTER_LANCZOS4).astype(np.float32)
    hard=cv2.resize(mask,(w,h),interpolation=cv2.INTER_NEAREST)
    expanded=cv2.dilate(hard,np.ones((15,15),np.uint8))
    soft=cv2.GaussianBlur(expanded,(0,0),max(3,w/290)).astype(np.float32)/255
    soft=np.maximum(soft,hard/255)[...,None]
    transition=(soft[...,0]>0)&(hard==0)
    _,_,transition_stats,_=cv2.connectedComponentsWithStats(transition.astype(np.uint8))
    transition_regions=[{'x':int(x),'y':int(y),'width':int(rw),'height':int(rh)}
                        for x,y,rw,rh,area in transition_stats[1:] if area]
    out=np.clip(high_donor*soft+src.astype(np.float32)*(1-soft),0,255).astype(np.uint8)
    buffer=io.BytesIO();Image.fromarray(out).save(buffer,'JPEG',quality=95,subsampling=0)
    report.update(applied=True,regions=regions,filled_ratio=round(coverage,4),
                  reason_code='applied',coverage=float(np.mean(hard>0)),
                  transition_regions=transition_regions,transition_coverage=float(np.mean(transition)),
                  region_selection='horizontal_strip_and_corner',
                  overlay_evidence='source_boundary_absent_in_donor',
                  method='仅融合可信横条和角落编号，保留其他区域细节；修补区非原生高清')
    return buffer.getvalue(),report


def repair_from_donor(source, donor):
    """Keep the established local repair; use the wide band only as fallback."""
    output,report=_repair_from_donor_trusted(source,donor)
    if report['applied'] and len(report['regions'])>=2:
        return output,report
    if report.get('reason_code') in ('reference_overlay_suspected','reference_check_unavailable'):
        return output,report
    src=np.array(ImageOps.exif_transpose(Image.open(io.BytesIO(source))).convert('RGB'))
    small=np.array(ImageOps.exif_transpose(Image.open(io.BytesIO(donor))).convert('RGB'))
    def unsafe_reference(a,b,box,threshold,raw_reference):
        try:
            return reference_has_new_text_edges(a,b,box,threshold,raw_reference=raw_reference)
        except ReferenceCheckUnavailable:
            return True
    wide_result=repair_verified_band(src,small,donor,
        reference_text_guard=unsafe_reference)
    return wide_result if wide_result is not None else (output,report)
